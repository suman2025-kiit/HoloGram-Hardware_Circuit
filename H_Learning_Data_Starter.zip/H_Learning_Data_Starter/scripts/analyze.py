#!/usr/bin/env python3
"""Validate H-Learning CSV logs and calculate descriptive metrics.

Default mode rejects synthetic rows. All demo outputs are explicitly labelled.
Python 3.10+ standard library only. No package installation required.
"""
import argparse
import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


def read_rows(path, kind):
    if not path.exists():
        raise ValueError(f'Missing input file: {path}')
    with path.open(newline='', encoding='utf-8-sig') as f:
        rows = [r for r in csv.DictReader(f) if any(v.strip() for v in r.values() if v)]
    for i, row in enumerate(rows, 2):
        if row.get('record_type') != kind:
            raise ValueError(f'{path.name}:{i}: expected record_type={kind!r}')
    return rows


def number(row, key, optional=False):
    value = row.get(key, '')
    if value == '' and optional:
        return None
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValueError(f'Invalid or missing {key}: {value!r}') from None
    if not math.isfinite(value):
        raise ValueError(f'Non-finite {key}')
    return value


def describe(values):
    if not values:
        return {'n': 0, 'mean': None, 'median': None, 'p95_nearest_rank': None}
    ordered = sorted(values)
    return {'n': len(values), 'mean': statistics.mean(values),
            'median': statistics.median(values),
            'p95_nearest_rank': ordered[math.ceil(.95 * len(ordered)) - 1]}


def analyze(folder, mode='real', raw_root=None, evaluation_split=None):
    kind = 'synthetic_demo' if mode == 'demo' else 'real_measurement'
    evaluation_split = evaluation_split or ('all' if mode == 'demo' else 'test')
    trials = read_rows(folder / 'trials.csv', kind)
    if not trials:
        raise ValueError('No trial records. Fill templates with real observations first.')
    ids, participant_splits, sequence_splits = {}, {}, {}
    allowed = {'SELECT', 'ROTATE', 'ZOOM', 'NEXT', 'NONE'}
    for row in trials:
        tid = row['trial_id']
        if not tid or tid in ids:
            raise ValueError(f'Missing or duplicate trial_id: {tid}')
        ids[tid] = row
        if row['method'] not in {'fsm', 'direct_gesture', 'mouse_keyboard'}:
            raise ValueError(f'Unknown method in {tid}')
        if row['command_expected'] not in allowed or row['command_executed'] not in allowed:
            raise ValueError(f'Unknown command in {tid}')
        for key, registry in [('participant_id', participant_splits), ('source_sequence_id', sequence_splits)]:
            value = row[key]
            if not value:
                raise ValueError(f'Missing {key} in {tid}')
            if value in registry and registry[value] != row['split']:
                raise ValueError(f'{key} leakage across splits: {value}')
            registry[value] = row['split']
        if row['split'] not in {'train', 'validation', 'test'}:
            raise ValueError(f'Invalid split in {tid}')
        if number(row, 'duration_s') <= 0:
            raise ValueError(f'Non-positive duration in {tid}')
        if row['excluded'] not in {'0', '1'}:
            raise ValueError(f'excluded must be 0 or 1 in {tid}')
        if row['excluded'] == '1' and not row['exclusion_reason']:
            raise ValueError(f'Missing exclusion reason in {tid}')
        if row['command_expected'] != 'NONE' and row['task_completed'] not in {'0', '1'}:
            raise ValueError(f'Missing task outcome in {tid}')
        count=number(row, 'unintended_action_count')
        if count < 0 or count != int(count):
            raise ValueError(f'Invalid unintended action count in {tid}')
        for first, last in [('input_event_ms', 'display_update_ms'), ('tracking_loss_ms', 'tracking_recovered_ms')]:
            a, b = number(row, first, True), number(row, last, True)
            if b is not None and a is not None and b < a:
                raise ValueError(f'Negative interval {first}/{last} in {tid}')
        if not row['clock_domain']:
            raise ValueError(f'Missing clock domain in {tid}')
        if mode == 'real':
            for field in ('ui_log_path', 'capture_path'):
                if not row[field] or not ((raw_root or folder) / row[field]).is_file() or ((raw_root or folder) / row[field]).stat().st_size==0:
                    raise ValueError(f'Missing raw evidence file {field} in {tid}')

    selected_ids={r['trial_id'] for r in trials if evaluation_split=='all' or r['split']==evaluation_split}
    if not selected_ids:
        raise ValueError(f'No trials in requested evaluation split: {evaluation_split}')
    grouped = defaultdict(list)
    for r in trials:
        if r['excluded'] == '0' and r['trial_id'] in selected_ids:
            grouped[(r['method'], r['split'])].append(r)
    results = []
    for (method, split), rows in sorted(grouped.items()):
        command_rows = [r for r in rows if r['command_expected'] != 'NONE']
        negative_rows = [r for r in rows if r['command_expected'] == 'NONE']
        latency, recovery = [], []
        for r in rows:
            a, b = number(r, 'input_event_ms', True), number(r, 'display_update_ms', True)
            if r['command_expected'] != 'NONE' and r['command_expected'] == r['command_executed'] and a is not None and b is not None:
                latency.append(b-a)
            a, b = number(r, 'tracking_loss_ms', True), number(r, 'tracking_recovered_ms', True)
            if a is not None and b is not None:
                recovery.append(b-a)
        results.append({'method': method, 'split': split, 'trials': len(rows),
                        'participants': len({r['participant_id'] for r in rows}),
                        'command_trials': len(command_rows), 'no_command_windows': len(negative_rows),
                        'correct_command_rate': sum(r['command_expected'] == r['command_executed'] for r in command_rows)/len(command_rows) if command_rows else None,
                        'task_success_rate': sum(int(r['task_completed']) for r in command_rows)/len(command_rows) if command_rows else None,
                        'false_activation_rate_per_window': sum(r['command_executed'] != 'NONE' for r in negative_rows)/len(negative_rows) if negative_rows else None,
                        'unintended_actions_per_minute': sum(int(r['unintended_action_count']) for r in rows)/(sum(float(r['duration_s']) for r in rows)/60),
                        'correct_command_latency_ms': describe(latency), 'recovery_ms': describe(recovery),
                        'tracking_loss_episodes':sum(r['tracking_loss_ms']!='' for r in rows),
                        'unrecovered_episodes':sum(r['tracking_loss_ms']!='' and r['tracking_recovered_ms']=='' for r in rows)})

    pose = None
    joint_path = folder/'joints.csv'
    if joint_path.exists():
        joints = read_rows(joint_path, kind)
        keyset, errors, evaluable, correct, predicted = set(), [], 0, 0, 0
        for r in joints:
            if r['trial_id'] not in ids:
                raise ValueError('Joint record references an unknown trial')
            key = (r['trial_id'], r['frame_id'], r['joint_name'])
            if key in keyset:
                raise ValueError(f'Duplicate joint record: {key}')
            keyset.add(key)
            if r['coordinate_frame'] not in {'synthetic_world_m', 'camera_m_calibrated'}:
                raise ValueError('Pose errors require matching, calibrated coordinates in metres')
            if mode == 'real' and r['coordinate_frame'] != 'camera_m_calibrated':
                raise ValueError('Real mode requires calibrated metric coordinates')
            if r['ground_truth_valid'] not in {'0','1'}:
                raise ValueError('ground_truth_valid must be 0 or 1')
            if r['ground_truth_valid'] != '1' or ids[r['trial_id']]['excluded'] == '1' or r['trial_id'] not in selected_ids:
                continue
            evaluable += 1
            gt = [number(r, f'gt_{a}_m') for a in 'xyz']
            pr = [number(r, f'pred_{a}_m', True) for a in 'xyz']
            if any(v is None for v in pr):
                continue  # Missing predictions count as PCK failures, not removed observations.
            predicted += 1
            err = math.sqrt(sum((x-y)**2 for x,y in zip(gt,pr)))
            errors.append(err)
            correct += err <= .1
        pose = {'valid_ground_truth_joints': evaluable, 'predicted_joints': predicted,
                'prediction_coverage': predicted/evaluable if evaluable else None,
                'pck_at_0_1_m': correct/evaluable if evaluable else None,
                'mpjpe_mm_on_available_predictions': 1000*statistics.mean(errors) if errors else None}

    energy = []
    power_path = folder/'power.csv'
    if power_path.exists():
        power = read_rows(power_path, kind)
        per_run = defaultdict(list)
        for r in power:
            if r['trial_id'] not in ids:
                raise ValueError('Power record references an unknown trial')
            if mode == 'real' and (not r['instrument_id'] or not r['measurement_scope']):
                raise ValueError('Missing power instrument or measurement scope')
            t,v,i = (number(r,k) for k in ('timestamp_ms','voltage_v','current_a'))
            if min(v,i) < 0:
                raise ValueError('Negative consumption voltage/current')
            per_run[r['trial_id']].append((t,v*i,r['measurement_scope']))
        for tid, samples in per_run.items():
            if ids[tid]['excluded'] == '1' or tid not in selected_ids:
                continue
            samples.sort()
            if len(samples) < 2 or len({s[2] for s in samples}) != 1:
                raise ValueError(f'Insufficient samples or mixed power scopes in {tid}')
            if any(b[0] <= a[0] for a,b in zip(samples,samples[1:])):
                raise ValueError(f'Duplicate/non-increasing power timestamps in {tid}')
            seconds = (samples[-1][0]-samples[0][0])/1000
            joules = sum((a[1]+b[1])/2*(b[0]-a[0])/1000 for a,b in zip(samples,samples[1:]))
            energy.append({'trial_id':tid,'measurement_scope':samples[0][2],
                           'window_s':seconds,'energy_mwh':joules/3.6,
                           'mean_power_w':joules/seconds,'maximum_sampled_power_w':max(s[1] for s in samples)})
    return {'record_type':kind,'evaluation_split':evaluation_split,'notice':'Synthetic examples only; not research results.' if mode=='demo' else 'Descriptive results from supplied logs; audit provenance and study design before reporting.',
            'trial_summary':results,'pose_summary':pose,'power_summary':energy,
            'ssim':None,'ssim_note':'Not calculated: supply aligned reference/predicted images and specify data range, masks, and reconstruction target.',
            'statistics_note':'Frames/trials are not independent participants. Use participant-level paired estimates and uncertainty for research comparisons.'}


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--mode',choices=['real','demo'],default='real')
    p.add_argument('--raw-root',type=Path)
    p.add_argument('--split',choices=['train','validation','test','all'],default=None)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    try:
        result=analyze(a.input,a.mode,a.raw_root,a.split)
    except (ValueError, KeyError) as e:
        p.exit(2,f'Validation failed: {e}\n')
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(f'Wrote {a.output} ({result["record_type"]})')
