import tempfile
import unittest
from pathlib import Path

from h_learning.signals import FrameSignals,read_signals,write_csv
from h_learning.validation import binary_metrics,session_report


class IOTests(unittest.TestCase):
    def test_csv_roundtrip_preserves_validity_types(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"signals.csv"
            original=FrameSignals(1,0.0,start=True,source_kind="synthetic_test_vector")
            write_csv(path,[original.as_dict()])
            self.assertEqual(list(read_signals(path)),[original])

    def test_invalid_mode_and_nan_rejected(self):
        with self.assertRaises(ValueError): FrameSignals(1,0,mode=2)
        with self.assertRaises(ValueError): FrameSignals(1,float("nan"))

    def test_confusion_matrix_denominators(self):
        m=binary_metrics([True,True,False,False],[True,False,True,False])
        self.assertEqual((m["tp"],m["fn"],m["fp"],m["tn"]),(1,1,1,1))
        self.assertEqual(m["f1"],.5)
        self.assertIsNone(binary_metrics([],[])["accuracy"])


class OptionalVisionMetricTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try: import numpy; import scipy
        except ImportError: raise unittest.SkipTest("Install .[metrics] for metric tests")

    def test_pck_counts_only_visible_ground_truth(self):
        from h_learning.vision_metrics import pck
        m=pck([[0,0,0],[.2,0,0],[9,9,9]],[[0,0,0],[0,0,0],[0,0,0]],[True,True,False])
        self.assertEqual(m["valid_keypoints"],2); self.assertEqual(m["pck"],.5)

    def test_ssim_identity_and_luminance_difference(self):
        import numpy as np
        from h_learning.vision_metrics import ssim
        image=np.linspace(0,1,400).reshape(20,20)
        self.assertAlmostEqual(ssim(image,image,data_range=1),1)
        self.assertLess(ssim(image,image*.4,data_range=1),.9)

    def test_missing_predictions_count_as_pck_failures(self):
        from h_learning.vision_metrics import pck
        m=pck([[0,0,0],[float("nan"),0,0]],[[0,0,0],[0,0,0]])
        self.assertEqual(m["valid_keypoints"],2); self.assertEqual(m["pck"],.5)
        self.assertEqual(m["missing_predictions"],1)


if __name__=="__main__": unittest.main()
