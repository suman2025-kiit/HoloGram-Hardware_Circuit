"""Fault injection, temporal behavior and application-state tests."""

import random
import unittest
from dataclasses import replace

from h_learning.controller import Controller, ControllerConfig, CommonState, EducationState, MonitorState
from h_learning.signals import FrameSignals


class Harness:
    def __init__(self, mode=1):
        self.c = Controller()
        self.i, self.time, self.mode = 0, -50.0, mode

    def step(self, *, dt=50.0, **kwargs):
        self.i += 1; self.time += dt
        data = dict(frame_id=self.i,time_ms=self.time,mode=self.mode,start=self.i==1,
                    depth_valid=True,pose_valid=True,depth_frame_id=self.i,pose_frame_id=self.i,
                    depth_time_ms=self.time,pose_time_ms=self.time,pose_confidence=.95,depth_rel=.6)
        data.update(kwargs)
        return self.c.step(FrameSignals(**data))

    def ready(self):
        for _ in range(9): self.step()
        return self

    def key(self, event, **kwargs):
        return self.step(gesture=event,command_source="keyboard",**kwargs)

    def hold(self,event,n=6,**kwargs):
        return [self.step(gesture=event,**kwargs) for _ in range(n)]


class ControllerTests(unittest.TestCase):
    def test_common_progression_and_readiness(self):
        h=Harness()
        codes=[h.step().common_code for _ in range(5)]
        self.assertEqual(codes,[1,2,3,3,4])
        self.assertEqual(h.c.education,EducationState.STUDENT_DETECTED)

    def test_pose_loss_immediately_blocks_commands(self):
        h=Harness().ready(); h.key("SELECT")
        r=h.key("ROTATE_RIGHT",pose_valid=False)
        self.assertFalse(r.fusion_valid); self.assertEqual(r.command,"")
        self.assertTrue(r.paused); self.assertEqual(r.rotation_deg,0)

    def test_stale_pose_frame_is_rejected(self):
        h=Harness().ready()
        r=h.key("SELECT",pose_frame_id=1)
        self.assertFalse(r.paired_valid); self.assertFalse(r.education_enable)

    def test_timestamp_skew_is_rejected(self):
        h=Harness().ready()
        r=h.step(pose_time_ms=h.time+100)
        self.assertFalse(r.paired_valid)

    def test_low_confidence_is_rejected(self):
        h=Harness().ready()
        self.assertFalse(h.step(pose_confidence=.1).fusion_valid)

    def test_cancel_has_priority_on_confirmation_frame(self):
        h=Harness().ready()
        h.hold("SELECT",n=4)
        r=h.step(gesture="SELECT",cancel=True)
        self.assertEqual(r.command,""); self.assertEqual(r.reason,"cancel")
        self.assertFalse(r.education_enable); self.assertEqual(r.selected_object,-1)

    def test_held_gesture_fires_once_and_neutral_rearms(self):
        h=Harness().ready()
        self.assertEqual(sum(r.command=="SELECT" for r in h.hold("SELECT",n=20)),1)
        h.step()
        self.assertEqual(sum(r.command=="SELECT" for r in h.hold("SELECT",n=6)),1)
        self.assertEqual(h.c.selected,1)

    def test_tracking_loss_clears_pending_confirmation(self):
        h=Harness().ready(); h.hold("SELECT",n=4)
        h.step(gesture="SELECT",pose_valid=False)
        recovering=h.hold("SELECT",n=4)
        self.assertFalse(any(r.command for r in recovering))
        self.assertEqual(sum(r.command=="SELECT" for r in h.hold("SELECT",n=5)),1)

    def test_gap_resets_readiness(self):
        h=Harness().ready()
        r=h.key("SELECT",dt=700)
        self.assertEqual(r.reason,"frame_gap"); self.assertFalse(r.fusion_valid)

    def test_mode_switch_clears_learning_and_blocks_one_update(self):
        h=Harness().ready(); h.key("SELECT")
        h.mode=0; r=h.step()
        self.assertFalse(r.monitor_enable); self.assertFalse(r.education_enable)
        self.assertEqual(r.reason,"mode_change"); self.assertEqual(r.selected_object,-1)
        for _ in range(6): r=h.key("SELECT")
        self.assertTrue(r.monitor_enable); self.assertFalse(r.education_enable); self.assertEqual(r.command,"")

    def test_rotate_requires_selection(self):
        h=Harness().ready()
        self.assertEqual(h.key("ROTATE_RIGHT").command,"")
        h.key("SELECT"); r=h.key("ROTATE_RIGHT")
        self.assertEqual(r.rotation_deg,15)

    def test_zoom_is_bounded(self):
        h=Harness().ready(); h.key("SELECT")
        for _ in range(50): r=h.key("ZOOM_IN")
        self.assertEqual(r.zoom,2.5)
        for _ in range(70): r=h.key("ZOOM_OUT")
        self.assertEqual(r.zoom,.4)

    def test_incorrect_answer_requires_remediation(self):
        h=Harness().ready(); h.key("SELECT")
        h.key("ANSWER",answer="C"); r=h.step()
        self.assertEqual(r.education_state,"FEEDBACK"); self.assertEqual(r.feedback,"REMEDIATE")
        r=h.key("NEXT")
        self.assertEqual(r.lesson_index,0); self.assertEqual(r.education_state,"CONTENT_DISPLAYED")

    def test_correct_answer_advances_and_three_lessons_complete(self):
        h=Harness().ready()
        for answer in ("A","B","A"):
            h.key("ANSWER",answer=answer); h.step(); r=h.key("NEXT")
        self.assertEqual(r.education_state,"LESSON_COMPLETED")
        self.assertEqual(r.command,"COMPLETE")

    def test_invalid_answer_is_not_accepted(self):
        h=Harness().ready()
        self.assertEqual(h.key("ANSWER",answer="Z").command,"")

    def test_lesson_not_ready_blocks_command(self):
        h=Harness().ready()
        r=h.key("SELECT",lesson_ready=False)
        self.assertFalse(r.education_enable); self.assertEqual(r.command,"")

    def test_monitor_requires_time_and_frame_persistence(self):
        h=Harness(mode=0).ready()
        rs=[h.step(abnormal_evidence=True) for _ in range(5)]
        self.assertFalse(any(r.alert for r in rs))
        self.assertTrue(h.step(abnormal_evidence=True).alert)
        self.assertTrue(h.step(abnormal_evidence=False).alert)
        self.assertFalse(h.step(reset=True).alert)

    def test_monitor_loss_clears_unconfirmed_evidence(self):
        h=Harness(mode=0).ready(); h.hold("NONE",n=4,abnormal_evidence=True)
        h.step(pose_valid=False,abnormal_evidence=True)
        rs=h.hold("NONE",n=6,abnormal_evidence=True)
        self.assertFalse(any(r.alert for r in rs))

    def test_no_start_means_no_outputs(self):
        h=Harness()
        for _ in range(20): r=h.step(start=False,gesture="SELECT")
        self.assertFalse(r.fusion_valid); self.assertEqual(r.common_state,"IDLE")

    def test_reset_without_start_does_not_activate_idle(self):
        h=Harness(); r=h.step(start=False,reset=True)
        self.assertFalse(r.fusion_valid); self.assertEqual(r.common_state,"IDLE")

    def test_duplicate_timestamp_and_frame_fail(self):
        c=Controller(); s=FrameSignals(1,0)
        c.step(s)
        with self.assertRaises(ValueError): c.step(s)

    def test_fuzz_5000_frames_keeps_invariants(self):
        h=Harness(); rng=random.Random(20261006)
        for _ in range(5000):
            if rng.random()<.02: h.mode=1-h.mode
            i=h.i+1
            r=h.step(pose_valid=rng.random()>.07,depth_valid=rng.random()>.03,
                     pose_frame_id=i if rng.random()>.03 else max(0,i-1),
                     cancel=rng.random()<.03,reset=rng.random()<.02,
                     gesture=rng.choice(("NONE","SELECT","ROTATE_RIGHT","ANSWER","NEXT")),answer="A",
                     abnormal_evidence=rng.random()<.4)
            self.assertFalse(r.monitor_enable and r.education_enable)
            if r.command: self.assertTrue(r.education_enable and r.paired_valid)
            if r.alert: self.assertTrue(r.monitor_enable and h.mode==0)


if __name__=="__main__": unittest.main()

