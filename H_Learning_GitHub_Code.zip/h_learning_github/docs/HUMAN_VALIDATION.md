# Collect a defensible learning-validation dataset

The included UR Fall recordings provide no student-learning labels. The empty
templates are schemas, not a human dataset.

Use a defined set of spatial-learning tasks and educator-reviewed content.
Recruit participants under the relevant consent/ethics process, assign
pseudonymous IDs and record the intended interaction condition. Collect
keyboard/mouse and depth–pose gesture sessions with counterbalanced order,
matched content and consistent display/camera settings. Specify sample size
and the primary outcomes before analyzing the observations.

1. Record a baseline knowledge/spatial test.
2. Execute actual lesson sessions with `h-learning run --camera 0`.
3. Have an independent annotator mark gesture-intention windows from the
   recording; do not use the classifier's output as its own ground truth.
4. Count task success, wrong/extra commands, retries, completion time and
   recovery episodes with a predefined coding guide.
5. Collect post-test scores and, where appropriate, standardized workload and
   usability questionnaire scores. Record the questionnaire version/scoring.
6. Analyze within-participant or between-group effects according to the study
   design, with uncertainty intervals. Do not treat frames as independent
   participants or infer learning gains from FSM state transitions.

`data/templates/study_outcomes.csv` provides a participant/session schema.
`interaction_annotations.csv` provides independent intention windows in the
same source-time coordinates as `trace.csv`. An `ANSWER` intention window is
different from an independently correct answer: task correctness comes from
the lesson key and participant response, and learning gain comes from tests.

Report human outcomes separately from vision accuracy, software timing,
circuit simulation and measured energy. The included software renderer does
not demonstrate an optical holographic display; a physical-display study
must state the actual apparatus and measurement setup.

