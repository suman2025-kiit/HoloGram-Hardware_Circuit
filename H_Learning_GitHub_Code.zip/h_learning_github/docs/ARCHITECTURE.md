# Architecture and manuscript mapping

One frame supplies both neural models. Inference completes synchronously;
image landmarks and relative inverse depth are logged from the same source.
The common gate checks frame IDs, source times, confidence and validity.
Only one mode receives gated application updates.

| Manuscript element | This repository | Practical scope |
|---|---|---|
| MiDaS / depth equation | `vision.py`, official small ONNX | Actual pretrained inference and bounded EMA; no resistor-coded network or optical-flow warp |
| BlazePose / skeletal processing | `vision.py`, official Pose Landmarker | Actual model landmarks; no claimed equivalence to the manuscript's hand-written pose equation |
| Depth–pose fusion and D-latch | Same-frame association, joint depth samples and stable register in `controller.py` | Numerical data remain separate from the Boolean validity gate; invalid current tracking blocks application output |
| Table II common automaton | `CommonState`, `Controller.step` | Five state codes, configurable stability and recovery |
| Educational automaton | `EducationState`, `_education_step` | Eight states with real object controls, quiz answer comparison, remediation and completion |
| Monitoring automaton | `MonitorState`, `_monitor_step` | Six states with documented threshold evidence and temporal confirmation |
| Mode selector | `FrameSignals.mode` and mutually exclusive enables | Mode switch resets histories and requires reacquisition |
| Table III compact encoding | `rtl/h_learning_controller.sv` and MATLAB builder | A separate eight-state control component; not the complete composite software state space |
| Voltage mapping / QSPICE | `export_interfaces.py` | Post-inference signal interface and gates; external circuit execution required |
| WaveDrom timing | Exported timing JSON | Rendering of sampled signals, not verification |
| Power and battery analysis | `scripts/analyze_power.py` | Requires actual external-meter readings; no sensor values manufactured |
| Vision-quality claims | `evaluate_vision.py` | Requires independent registered/metric ground truth |
| Human-learning claims | Recorder, annotation evaluator and study templates | Requires new participant observations and a comparison study |

The software alert state remains accepted until reset/mode change. Its output
is masked while synchronized tracking is unavailable. Applications requiring a
physical alarm to remain active through tracking loss should add a separately
acknowledged alarm channel and validate that policy; the current trace exposes
both the retained state and masked output.

The compact RTL/MATLAB models intentionally use different sample-count
semantics and explicit START after reset/cancel. They are not asserted to be
behaviorally equivalent to all Python application features. An actual board
integration must provide coherent host-to-logic transfers, clock-domain
crossing, watchdog timing, I/O routing and platform-specific verification.

The pumping lemma describes language regularity; this repository uses
executable invariants and fault/behavior tests for controller validation.

