# Recorded validation data card

| Item | Description |
|---|---|
| Provider | UR Fall Detection Dataset, Michał Kępski, University of Rzeszow |
| Official source | https://fenix.ur.edu.pl/mkepski/ds/uf.html |
| Licence | CC BY-NC-SA 4.0 |
| Original observations bundled | 11,544 feature rows; 70 camera-0 timing files |
| Timed derivative | 11,524 rows after exact sequence/frame timestamp join |
| Missing-time observations | 20 rows: `adl-37`, frames 331–350; preserved in raw CSV |
| Included image recordings | `fall-01`, `adl-01`, complete camera-0 RGB/depth PNG archives and previews |
| Sequence split | Train: fall 01–18 and ADL 01–24; validation: fall 19–24 and ADL 25–32; test: fall 25–30 and ADL 33–40 |
| Split limitation | Participant-independent separation cannot be established from these metadata |
| Dataset timing | Camera-0 recorded timestamps, not execution wall time |
| Posture labels | `-1`: not lying; `0`: transition/falling; `1`: lying |
| Intended use here | Monitoring/posture reference benchmark and prerecorded vision/control replay |
| Unavailable labels | Independent 33-joint metric pose, intended education gestures, learning outcomes, physical power |

The eight original feature columns are retained with descriptive snake-case
names. They describe body-region geometry and height-related measurements
computed by the provider from depth data. They are not substituted for model
predictions in the neural pipeline. Transitional label-0 frames remain in
replay but are excluded from the binary posture confusion matrices.

ADL recordings can contain deliberate lying. The fixed depth baseline's
posture scores and any-alert fall-sequence scores consequently answer
different questions and are reported separately. Detection of physical motion
does not determine human intent.

Raw depth rescaling must follow the provider's camera/sequence documentation:
camera-0 fall scale is 6000 mm and ADL scale is 7000 mm for PNG16 range 65535.
Camera alignment and valid-pixel masks must be established before comparing
these images with monocular estimates. No metric-depth SSIM/PCK result is
inferred from the data card.

All original downloads are identified by URL, bytes and SHA256 in
`data/urfall/download_manifest.json`. Transformations and excluded rows are
recorded in the processed CSV's adjacent manifest.

