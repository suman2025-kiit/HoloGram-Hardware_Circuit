"""Evidence reports from actual execution traces; no target manuscript values are inserted."""

from __future__ import annotations

import math


def boolean(value) -> bool:
    return value is True or str(value).lower() in {"true", "1"}


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    index = (len(values) - 1) * p / 100
    low, high = math.floor(index), math.ceil(index)
    return values[low] + (values[high] - values[low]) * (index - low)


def binary_metrics(truth: list[bool], prediction: list[bool]) -> dict:
    if len(truth) != len(prediction):
        raise ValueError("Truth and prediction lengths differ")
    tp = sum(t and p for t,p in zip(truth,prediction))
    tn = sum(not t and not p for t,p in zip(truth,prediction))
    fp = sum(not t and p for t,p in zip(truth,prediction))
    fn = sum(t and not p for t,p in zip(truth,prediction))
    ratio = lambda a,b: a/b if b else None
    return {"n":len(truth), "tp":tp,"tn":tn,"fp":fp,"fn":fn,
            "accuracy":ratio(tp+tn,len(truth)), "precision":ratio(tp,tp+fp),
            "recall":ratio(tp,tp+fn), "specificity":ratio(tn,tn+fp), "f1":ratio(2*tp,2*tp+fp+fn)}


def session_report(rows: list[dict]) -> dict:
    violations = {"simultaneous_branch_enable":0, "command_without_valid_tracking":0,
                  "alert_outside_monitoring":0, "command_during_cancel":0,
                  "enabled_on_mismatched_frame":0, "enabled_on_invalid_fusion":0}
    for row in rows:
        mon, edu, paired, fused = (boolean(row[key]) for key in ("monitor_enable","education_enable","paired_valid","fusion_valid"))
        command = bool(row.get("command", ""))
        violations["simultaneous_branch_enable"] += int(mon and edu)
        violations["command_without_valid_tracking"] += int(command and not (edu and paired and fused))
        violations["alert_outside_monitoring"] += int(boolean(row["alert"]) and (int(row["mode"]) != 0 or not mon))
        violations["command_during_cancel"] += int(command and boolean(row["cancel"]))
        mismatch = not (int(row["frame_id"]) == int(row["depth_frame_id"]) == int(row["pose_frame_id"]))
        violations["enabled_on_mismatched_frame"] += int((mon or edu) and mismatch)
        violations["enabled_on_invalid_fusion"] += int((mon or edu) and not fused)
    timings = [float(row["processing_ms"]) for row in rows if float(row.get("processing_ms",0)) > 0]
    confirmations = [float(row["command_confirmation_ms"]) for row in rows if row.get("command")]
    report = {
        "frames":len(rows), "source_kinds":sorted({row.get("source_kind","unspecified") for row in rows}),
        "paired_valid_frames":sum(boolean(row["paired_valid"]) for row in rows),
        "fusion_valid_frames":sum(boolean(row["fusion_valid"]) for row in rows),
        "paused_frames":sum(boolean(row["paused"]) for row in rows),
        "committed_commands":sum(bool(row.get("command")) for row in rows),
        "alert_frames":sum(boolean(row["alert"]) for row in rows),
        "invariant_violations":violations,
        "serial_processing_ms":{"n":len(timings), "mean":sum(timings)/len(timings) if timings else None,
                                "p50":percentile(timings,50),"p95":percentile(timings,95),
                                "max":max(timings) if timings else None},
        "gesture_confirmation_ms":{"n":len(confirmations),"p50":percentile(confirmations,50),"p95":percentile(confirmations,95)},
        "interpretation":"Timing measures host processing, not sensor-to-display latency or FPGA timing. No measured power or learning gains are inferred.",
    }
    labelled = [r for r in rows if str(r.get("gt_label","")) in {"-1","1"} and int(r["mode"]) == 0]
    if labelled:
        report["lying_posture_alert_frame_metrics"] = binary_metrics([str(r["gt_label"]) == "1" for r in labelled], [boolean(r["alert"]) for r in labelled])
        report["posture_metric_note"] = "Official labels indicate lying/not lying; 0 transition and unlabelled frames excluded. Alert persistence and gate losses affect these descriptive metrics. They are not fraud labels."
    return report

