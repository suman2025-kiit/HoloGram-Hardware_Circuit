"""Deterministic, independent common/monitoring/learning FSM registers.

Numeric depth/pose fusion is not a logical AND. The AND below combines validity
flags; frame identity and timestamps are checked before application execution.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from enum import IntEnum
from pathlib import Path

from .signals import FrameSignals


class CommonState(IntEnum):
    IDLE = 0
    DEPTH_READY = 1
    POSE_READY = 2
    FUSION_READY = 3
    OUTPUT_STABLE = 4


class MonitorState(IntEnum):
    NEUTRAL = 0
    WALK = 1
    BEND = 2
    FALL = 3
    SUSPICIOUS = 4
    ALERT = 5


class EducationState(IntEnum):
    IDLE = 0
    STUDENT_DETECTED = 1
    LESSON_READY = 2
    CONTENT_DISPLAYED = 3
    STUDENT_INTERACTION = 4
    ASSESSMENT = 5
    FEEDBACK = 6
    LESSON_COMPLETED = 7


@dataclass(frozen=True)
class ControllerConfig:
    max_skew_ms: float = 20.0
    max_frame_gap_ms: float = 500.0
    minimum_pose_confidence: float = 0.5
    stable_frames: int = 2
    gesture_hold_ms: float = 200.0
    gesture_min_frames: int = 2
    alert_hold_ms: float = 250.0
    alert_min_frames: int = 2
    lesson_count: int = 3
    object_count: int = 3

    def __post_init__(self) -> None:
        if any(getattr(self, name) < 0 for name in
               ("max_skew_ms", "gesture_hold_ms", "alert_hold_ms")):
            raise ValueError("Durations must be non-negative")
        if self.max_frame_gap_ms <= 0:
            raise ValueError("max_frame_gap_ms must be positive")
        if not 0 <= self.minimum_pose_confidence <= 1:
            raise ValueError("Pose confidence threshold must lie in [0,1]")
        if any(getattr(self, name) < 1 for name in
               ("stable_frames", "gesture_min_frames", "alert_min_frames", "lesson_count", "object_count")):
            raise ValueError("Frame, object, and lesson counts must be positive")

    @classmethod
    def load(cls, path: Path | None) -> "ControllerConfig":
        return cls(**json.loads(path.read_text())) if path else cls()


@dataclass
class Decision:
    common_state: str
    monitor_state: str
    education_state: str
    common_code: int
    monitor_code: int
    education_code: int
    paired_valid: bool
    fusion_valid: bool
    monitor_enable: bool
    education_enable: bool
    alert: bool
    command: str
    command_confirmation_ms: float
    feedback: str
    lesson_index: int
    selected_object: int
    rotation_deg: float
    zoom: float
    latched_depth_rel: float
    paused: bool
    reason: str

    def as_dict(self) -> dict:
        return asdict(self)


class TemporalConfirm:
    """One commit per held gesture; a neutral frame is needed to re-arm it."""

    def __init__(self, hold_ms: float, min_frames: int):
        self.hold_ms, self.min_frames = hold_ms, min_frames
        self.clear()

    def clear(self) -> None:
        self.candidate = "NONE"
        self.since = 0.0
        self.count = 0
        self.fired = False

    def update(self, event: str, now_ms: float) -> tuple[str, float]:
        if event == "NONE":
            self.clear()
            return "", 0.0
        if event != self.candidate:
            self.candidate, self.since, self.count, self.fired = event, now_ms, 1, False
        else:
            self.count += 1
        duration = now_ms - self.since
        if not self.fired and self.count >= self.min_frames and duration >= self.hold_ms:
            self.fired = True
            return event, duration
        return "", 0.0


class Controller:
    MANIPULATION = {"SELECT", "ROTATE_LEFT", "ROTATE_RIGHT", "ZOOM_IN", "ZOOM_OUT", "NEXT", "PREVIOUS", "ANSWER"}

    def __init__(self, config: ControllerConfig | None = None, answer_keys: tuple[str, ...] = ("A", "B", "A")):
        self.config = config or ControllerConfig()
        if len(answer_keys) != self.config.lesson_count:
            raise ValueError("One answer key is required per lesson")
        self.answer_keys = answer_keys
        self.last_time = -1.0
        self.last_frame = -1
        self.mode: int | None = None
        self.confirm = TemporalConfirm(self.config.gesture_hold_ms, self.config.gesture_min_frames)
        self._reset()

    def _reset(self, *, running: bool = False) -> None:
        self.common = CommonState.DEPTH_READY if running else CommonState.IDLE
        self.monitor = MonitorState.NEUTRAL
        self.education = EducationState.IDLE
        self.running = running
        self.stable_count = 0
        self.latched_depth = 0.0
        self.lesson = 0
        self.selected = -1
        self.rotation = 0.0
        self.zoom = 1.0
        self.feedback = ""
        self.pending_answer = ""
        self.evidence_since: float | None = None
        self.evidence_frames = 0
        self.confirm.clear()

    def _paired(self, signal: FrameSignals) -> bool:
        return (signal.depth_valid and signal.pose_valid
                and signal.pose_confidence >= self.config.minimum_pose_confidence
                and signal.frame_id == signal.depth_frame_id == signal.pose_frame_id
                and abs(signal.depth_time_ms - signal.pose_time_ms) <= self.config.max_skew_ms
                and abs(signal.depth_time_ms - signal.time_ms) <= self.config.max_skew_ms
                and abs(signal.pose_time_ms - signal.time_ms) <= self.config.max_skew_ms)

    def _monitor_step(self, signal: FrameSignals) -> None:
        if self.monitor == MonitorState.ALERT:
            return  # Explicit reset/mode change clears an accepted alert.
        if signal.abnormal_evidence:
            if self.evidence_since is None:
                self.evidence_since = signal.time_ms
                self.evidence_frames = 0
            self.evidence_frames += 1
            self.monitor = MonitorState.FALL
            if (self.evidence_frames >= self.config.alert_min_frames
                    and signal.time_ms - self.evidence_since >= self.config.alert_hold_ms):
                self.monitor = MonitorState.ALERT
        else:
            was_fall = self.evidence_since is not None
            self.evidence_since, self.evidence_frames = None, 0
            self.monitor = (MonitorState.SUSPICIOUS if was_fall else
                            MonitorState.BEND if signal.knee_deg < 110 else
                            MonitorState.WALK if signal.motion_speed > 0.08 else MonitorState.NEUTRAL)

    def _education_step(self, signal: FrameSignals, event: str) -> str:
        if self.education == EducationState.IDLE:
            self.education = EducationState.STUDENT_DETECTED
        elif self.education == EducationState.STUDENT_DETECTED and signal.lesson_ready:
            self.education = EducationState.LESSON_READY
        elif self.education == EducationState.LESSON_READY and signal.lesson_ready:
            self.education = EducationState.CONTENT_DISPLAYED
        elif self.education == EducationState.ASSESSMENT:
            correct = self.pending_answer == self.answer_keys[self.lesson]
            self.feedback = "CORRECT" if correct else "REMEDIATE"
            self.education = EducationState.FEEDBACK
        elif self.education == EducationState.FEEDBACK and event == "NEXT":
            if self.feedback == "CORRECT":
                self.lesson += 1
                if self.lesson == self.config.lesson_count:
                    self.lesson -= 1
                    self.education = EducationState.LESSON_COMPLETED
                    return "COMPLETE"
            self.feedback, self.pending_answer = "", ""
            self.education = EducationState.CONTENT_DISPLAYED
            return "NEXT" if self.selected >= 0 else "RETRY"
        elif self.education in {EducationState.CONTENT_DISPLAYED, EducationState.STUDENT_INTERACTION}:
            if event not in self.MANIPULATION:
                return ""
            if event == "SELECT":
                self.selected = (self.selected + 1) % self.config.object_count
            elif event in {"ROTATE_LEFT", "ROTATE_RIGHT", "ZOOM_IN", "ZOOM_OUT"}:
                if self.selected < 0:
                    return ""  # State-dependent authorization: select an object first.
                if event.startswith("ROTATE"):
                    self.rotation = (self.rotation + (15 if event == "ROTATE_RIGHT" else -15)) % 360
                else:
                    self.zoom = max(0.4, min(2.5, self.zoom * (1.15 if event == "ZOOM_IN" else 1 / 1.15)))
            elif event == "NEXT":
                self.lesson = min(self.config.lesson_count - 1, self.lesson + 1)
            elif event == "PREVIOUS":
                self.lesson = max(0, self.lesson - 1)
            elif event == "ANSWER":
                if signal.answer not in {"A", "B", "C"}:
                    return ""
                self.pending_answer = signal.answer
                self.education = EducationState.ASSESSMENT
                return "ANSWER"
            self.education = EducationState.STUDENT_INTERACTION
            return event
        return ""

    def step(self, signal: FrameSignals) -> Decision:
        if signal.time_ms <= self.last_time or signal.frame_id <= self.last_frame:
            raise ValueError("Frame IDs and timestamps must increase strictly within a session")
        gap = self.last_time >= 0 and signal.time_ms - self.last_time > self.config.max_frame_gap_ms
        self.last_time, self.last_frame = signal.time_ms, signal.frame_id
        paired = self._paired(signal)
        mode_changed = self.mode is not None and self.mode != signal.mode
        self.mode = signal.mode
        command, delay, reason = "", 0.0, ""

        if signal.reset or mode_changed:
            self._reset(running=self.running or signal.start)
            reason = "reset" if signal.reset else "mode_change"
        elif signal.cancel:
            self.confirm.clear()
            self.selected = -1
            self.pending_answer, self.feedback = "", ""
            if self.education != EducationState.LESSON_COMPLETED:
                self.education = EducationState.CONTENT_DISPLAYED if self.education >= EducationState.CONTENT_DISPLAYED else EducationState.IDLE
            reason = "cancel"
        else:
            if signal.start:
                self.running = True
                if self.common == CommonState.IDLE:
                    self.common = CommonState.DEPTH_READY
                    reason = "start"
            elif self.running:
                if gap or not paired:
                    self.common = CommonState.DEPTH_READY
                    self.stable_count = 0
                    self.confirm.clear()
                    self.evidence_since, self.evidence_frames = None, 0
                    reason = "frame_gap" if gap else "tracking_or_sync_loss"
                elif self.common == CommonState.DEPTH_READY:
                    self.common = CommonState.POSE_READY
                elif self.common == CommonState.POSE_READY:
                    self.common = CommonState.FUSION_READY
                    self.stable_count = 0
                elif self.common == CommonState.FUSION_READY:
                    self.stable_count += 1
                    if self.stable_count >= self.config.stable_frames:
                        self.common = CommonState.OUTPUT_STABLE
                if self.common == CommonState.OUTPUT_STABLE and paired and not gap:
                    self.latched_depth = signal.depth_rel
                    if signal.mode == 0:
                        self.confirm.clear()
                        self._monitor_step(signal)
                    elif signal.lesson_ready:
                        # Keyboard/mouse are discrete comparison-condition events.
                        accepts_event = self.education in {EducationState.CONTENT_DISPLAYED, EducationState.STUDENT_INTERACTION, EducationState.FEEDBACK}
                        if not accepts_event:
                            event = ""
                            self.confirm.clear()
                        elif signal.command_source in {"keyboard", "mouse"}:
                            event = signal.gesture if signal.gesture != "NONE" else ""
                            self.confirm.clear()
                        else:
                            event, delay = self.confirm.update(signal.gesture, signal.time_ms)
                        command = self._education_step(signal, event)
                    else:
                        self.confirm.clear()
                        reason = "lesson_not_ready"

        blocked = bool(reason in {"reset", "mode_change", "cancel", "frame_gap"})
        fusion = self.running and self.common == CommonState.OUTPUT_STABLE and paired and not blocked
        monitor_enable = fusion and signal.mode == 0
        education_enable = fusion and signal.mode == 1 and signal.lesson_ready
        result = Decision(
            self.common.name, self.monitor.name, self.education.name,
            int(self.common), int(self.monitor), int(self.education), paired, fusion,
            monitor_enable, education_enable, monitor_enable and self.monitor == MonitorState.ALERT,
            command, delay if command else 0.0, self.feedback, self.lesson, self.selected,
            self.rotation, self.zoom, self.latched_depth, self.running and not fusion, reason,
        )
        # Runtime invariants remain active even when tests are not being run.
        if result.monitor_enable and result.education_enable:
            raise AssertionError("Both application branches enabled")
        if result.command and (not result.education_enable or not result.paired_valid):
            raise AssertionError("Command issued without current synchronized tracking")
        if result.alert and (signal.mode != 0 or not result.paired_valid):
            raise AssertionError("Alert issued outside synchronized monitoring")
        return result
