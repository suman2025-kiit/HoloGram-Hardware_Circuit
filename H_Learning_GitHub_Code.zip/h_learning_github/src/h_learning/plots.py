"""Publication-readable JPEG plots of logs; not imitation simulator screenshots."""

from __future__ import annotations

import csv
from pathlib import Path


def plot_trace(path: Path, out: Path) -> list[str]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from .validation import boolean
    with path.open(newline="",encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError("Empty trace")
    out.mkdir(parents=True,exist_ok=True)
    t = np.array([float(r["time_ms"])/1000 for r in rows])
    kind = ", ".join(sorted({r["source_kind"] for r in rows}))
    plt.rcParams.update({"font.size":12,"font.weight":"bold","axes.labelweight":"bold","axes.linewidth":1.3})
    def number(name): return np.array([float(r[name]) for r in rows])
    def flag(name): return np.array([int(boolean(r[name])) for r in rows])
    specs = [
        ("Figure_3_depth_pose.jpg",[("Relative inverse depth",number("depth_rel")),("Pose confidence",number("pose_confidence")),("Fusion valid",flag("fusion_valid"))],"Normalized value"),
        ("Figure_4_abnormality.jpg",[("Abnormal evidence",flag("abnormal_evidence")),("Monitoring alert",flag("alert")),("Monitor state code",number("monitor_code"))],"Flag / state code"),
        ("Figure_5_dual_mode.jpg",[("Mode M",number("mode")),("Monitoring enabled",flag("monitor_enable")),("Learning enabled",flag("education_enable"))],"Logic level"),
        ("Figure_6_learning.jpg",[("Education state code",number("education_code")),("Command committed",np.array([bool(r["command"]) for r in rows],int)),("Paused",flag("paused"))],"Flag / state code"),
    ]
    paths=[]
    for filename,series,ylabel in specs:
        fig,ax = plt.subplots(figsize=(10,4.4),layout="constrained")
        for label,y in series:
            ax.step(t,y,where="post",label=label,linewidth=2.5)
        ax.set(xlabel="Recorded or simulated time (s)",ylabel=ylabel)
        ax.legend(loc="upper right",fontsize=10,framealpha=.9)
        ax.grid(alpha=.25)
        fig.suptitle(f"H-Learning execution trace: {kind}",fontsize=12,fontweight="bold")
        target=out/filename
        fig.savefig(target,dpi=300,pil_kwargs={"quality":95}); plt.close(fig)
        paths.append(str(target))
    return paths

