"""A real software interaction view; no simulator window or optical capture is fabricated."""

from __future__ import annotations

import math

KEYS = {ord("s"): "SELECT", ord("a"): "ROTATE_LEFT", ord("d"): "ROTATE_RIGHT",
        ord("+"): "ZOOM_IN", ord("="): "ZOOM_IN", ord("-"): "ZOOM_OUT",
        ord("n"): "NEXT", ord("p"): "PREVIOUS", ord("1"): "ANSWER",
        ord("2"): "ANSWER", ord("3"): "ANSWER"}
EDGES = [(11,12),(11,13),(13,15),(12,14),(14,16),(11,23),(12,24),(23,24),(23,25),(25,27),(24,26),(26,28)]


def draw(frame, inference: dict, decision, mode: int, lessons: list[dict]):
    import cv2
    import numpy as np
    h, w = frame.shape[:2]
    camera = cv2.resize(frame, (640, 480))
    for a, b in EDGES:
        points = inference["landmarks"]
        if points and min(points[a]["visibility"], points[b]["visibility"]) > 0.5:
            aa, bb = (tuple(round(points[k][axis] * size) for axis, size in (("x",640),("y",480))) for k in (a,b))
            cv2.line(camera, aa, bb, (40,240,50), 3, cv2.LINE_AA)
    depth = cv2.applyColorMap((inference["depth_relative"] * 255).astype(np.uint8), cv2.COLORMAP_TURBO)
    depth = cv2.resize(depth, (320, 240))
    panel = np.full((480, 640, 3), (24,25,28), np.uint8)
    font = cv2.FONT_HERSHEY_SIMPLEX
    color = (80,220,255) if not decision.paused else (30,170,255)
    if mode == 1:
        shapes = [
            ([(x,y,z) for x in (-1,1) for y in (-1,1) for z in (-1,1)], [(i,j) for i in range(8) for j in range(i+1,8) if bin(i^j).count("1")==1]),
            ([(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)], [(i,j) for i in range(6) for j in range(i+1,6) if i//2 != j//2]),
            ([(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)], [(i,j) for i in range(4) for j in range(i+1,4)]),
        ]
        lesson = lessons[decision.lesson_index]
        shape_index = decision.selected_object if decision.selected_object >= 0 else decision.lesson_index
        vertices, edges = shapes[shape_index % len(shapes)]
        angle = math.radians(decision.rotation_deg + 25)
        projected = []
        for x,y,z in vertices:
            rx, rz = x*math.cos(angle)+z*math.sin(angle), -x*math.sin(angle)+z*math.cos(angle)
            perspective = 1/(3.8+rz)
            projected.append((round(320+rx*250*decision.zoom*perspective), round(230-y*250*decision.zoom*perspective)))
        for a,b in edges:
            cv2.line(panel, projected[a], projected[b], color, 4, cv2.LINE_AA)
        cv2.putText(panel, f"Lesson {decision.lesson_index+1}: {lesson['title']}", (20,36), font, 0.8, (250,250,250), 2, cv2.LINE_AA)
        cv2.putText(panel, lesson["question"], (20,330), font, 0.60, (250,250,250), 2, cv2.LINE_AA)
        choices = "  ".join(f"{k}: {v}" for k,v in lesson["choices"].items())
        cv2.putText(panel, choices, (20,362), font, 0.7, (250,250,250), 2, cv2.LINE_AA)
        message = lesson["remediation"] if decision.feedback == "REMEDIATE" else decision.feedback
        cv2.putText(panel, message[:62], (20,399), font, 0.52, color, 2, cv2.LINE_AA)
    else:
        cv2.putText(panel, "Abnormal-motion monitoring", (20,45), font, 0.9, (250,250,250), 2, cv2.LINE_AA)
        cv2.putText(panel, decision.monitor_state, (40,225), font, 1.8, (40,40,240) if decision.alert else color, 3, cv2.LINE_AA)
        cv2.putText(panel, "Threshold heuristic; verify any alert.", (20,310), font, 0.7, (220,220,220), 2, cv2.LINE_AA)
    cv2.putText(panel, f"{decision.education_state if mode else decision.common_state}", (20,445), font, 0.6, color, 2, cv2.LINE_AA)
    camera[240:480,320:640] = depth
    cv2.putText(camera, "Relative inverse depth", (326,267), font, 0.48, (255,255,255), 2, cv2.LINE_AA)
    combined = np.hstack([camera, panel])
    footer = np.full((76,1280,3), (45,45,45), np.uint8)
    cv2.putText(footer, "s select | a/d rotate | +/- zoom | n/p lesson | 1/2/3 answer | x cancel | r reset | t mode | q quit", (12,28), font, 0.62, (255,255,255), 2, cv2.LINE_AA)
    cv2.putText(footer, f"Tracking {'PAUSED' if decision.paused else 'READY'} | M={mode} | gesture={inference['gesture']}", (12,60), font, 0.68, color, 2, cv2.LINE_AA)
    return np.vstack([combined, footer])

