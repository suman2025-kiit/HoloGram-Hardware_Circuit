"""Actual MiDaS ONNX and BlazePose/GHUM inference on the same image.

MiDaS produces relative inverse depth. MediaPipe world coordinates are model
estimates about the hip origin, not independently measured ground truth.
"""

from __future__ import annotations

import math
import time
from pathlib import Path


class VisionPipeline:
    def __init__(self, model_dir: Path, *, threads: int = 2, smoothing: float = 0.25):
        try:
            import cv2
            import mediapipe as mp
            import numpy as np
        except ImportError as exc:
            raise RuntimeError('Install vision dependencies: python -m pip install -e ".[vision]"') from exc
        if not 0 < smoothing <= 1:
            raise ValueError("Smoothing must lie in (0,1]")
        depth_path, pose_path = model_dir / "model-small.onnx", model_dir / "pose_landmarker_lite.task"
        for path in (depth_path, pose_path):
            if not path.is_file():
                raise FileNotFoundError(f"Missing {path}. Run python scripts/download_models.py")
        self.cv2, self.np, self.mp = cv2, np, mp
        cv2.setNumThreads(max(1, threads))
        self.depth_net = cv2.dnn.readNetFromONNX(str(depth_path))
        self.depth_net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.depth_net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        options = mp.tasks.vision.PoseLandmarkerOptions(
            base_options=mp.tasks.BaseOptions(model_asset_path=str(pose_path)),
            running_mode=mp.tasks.vision.RunningMode.VIDEO,
            num_poses=1, min_pose_detection_confidence=0.5,
            min_pose_presence_confidence=0.5, min_tracking_confidence=0.5,
        )
        self.pose = mp.tasks.vision.PoseLandmarker.create_from_options(options)
        self.smoothing, self.previous_depth = smoothing, None
        self.previous_hip, self.previous_time = None, None
        self.previous_landmarks = None
        self.last_mp_time = -1

    def _depth(self, bgr):
        cv2, np = self.cv2, self.np
        h, w = bgr.shape[:2]
        scale = 256 / max(h, w)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        small = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_CUBIC)
        left, top = (256 - nw) // 2, (256 - nh) // 2
        padded = cv2.copyMakeBorder(small, top, 256 - nh - top, left, 256 - nw - left, cv2.BORDER_REPLICATE)
        data = padded.astype(np.float32) / 255.0
        data = (data - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
        blob = np.ascontiguousarray(data.transpose(2, 0, 1)[None])
        self.depth_net.setInput(blob)
        raw = self.depth_net.forward().squeeze()
        if raw.ndim != 2 or not np.isfinite(raw).all():
            raise RuntimeError("Invalid MiDaS model output")
        raw = cv2.resize(raw, (256, 256), interpolation=cv2.INTER_CUBIC)
        raw = cv2.resize(raw[top:top + nh, left:left + nw], (w, h), interpolation=cv2.INTER_CUBIC)
        if self.previous_depth is not None and self.previous_depth.shape == raw.shape:
            # Bounded EMA; no optical-flow compensation is claimed.
            smoothed = self.smoothing * raw + (1 - self.smoothing) * self.previous_depth
        else:
            smoothed = raw
        self.previous_depth = smoothed
        low, high = np.percentile(smoothed, [2, 98])
        valid = bool(high - low > 1e-6)
        relative = np.clip((smoothed - low) / max(high - low, 1e-6), 0, 1).astype(np.float32)
        return raw.astype(np.float32), relative, valid

    @staticmethod
    def _landmark_dict(point) -> dict:
        return {"x": float(point.x), "y": float(point.y), "z": float(point.z),
                "visibility": float(point.visibility or 0), "presence": float(point.presence or 0)}

    @staticmethod
    def _angle(a, b, c) -> float:
        u = [a[k] - b[k] for k in ("x", "y", "z")]
        v = [c[k] - b[k] for k in ("x", "y", "z")]
        den = math.sqrt(sum(x*x for x in u) * sum(x*x for x in v))
        if den < 1e-9:
            return 180.0
        return math.degrees(math.acos(max(-1, min(1, sum(x*y for x, y in zip(u, v)) / den))))

    @staticmethod
    def decode_gesture(points: list[dict]) -> str:
        """Coarse body gestures only; this is not a finger/hand classifier."""
        if not points or any(points[i]["visibility"] < 0.5 for i in (0, 11, 12, 15, 16, 23, 24)):
            return "NONE"
        nose, ls, rs, lw, rw = (points[i] for i in (0, 11, 12, 15, 16))
        left_up, right_up = lw["y"] < nose["y"] - 0.04, rw["y"] < nose["y"] - 0.04
        if left_up and right_up:
            return "CANCEL"
        if left_up:
            return "SELECT"
        if right_up:
            return "NEXT"
        shoulder_y = (ls["y"] + rs["y"]) / 2
        both_level = abs(lw["y"] - shoulder_y) < 0.1 and abs(rw["y"] - shoulder_y) < 0.1
        span = abs(lw["x"] - rw["x"])
        if both_level and span > 0.65:
            return "ZOOM_IN"
        if both_level and span < 0.2:
            return "ZOOM_OUT"
        if abs(lw["y"] - ls["y"]) < 0.08 and abs(lw["x"] - ls["x"]) > 0.18:
            return "ROTATE_LEFT"
        if abs(rw["y"] - rs["y"]) < 0.08 and abs(rw["x"] - rs["x"]) > 0.18:
            return "ROTATE_RIGHT"
        hip_y = (points[23]["y"] + points[24]["y"]) / 2
        if lw["y"] > hip_y + 0.08 and rw["y"] > hip_y + 0.08 and span > 0.5:
            return "PREVIOUS"
        return "NONE"

    def infer(self, bgr, time_ms: float) -> dict:
        cv2, np, mp = self.cv2, self.np, self.mp
        start = time.perf_counter()
        raw, depth, depth_valid = self._depth(bgr)
        depth_end = time.perf_counter()
        mp_time = int(round(time_ms))
        if mp_time <= self.last_mp_time:
            raise ValueError("MediaPipe timestamps must increase by at least one millisecond")
        self.last_mp_time = mp_time
        rgb = np.ascontiguousarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        result = self.pose.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb), mp_time)
        pose_end = time.perf_counter()
        landmarks = [self._landmark_dict(p) for p in result.pose_landmarks[0]] if result.pose_landmarks else []
        world = [self._landmark_dict(p) for p in result.pose_world_landmarks[0]] if result.pose_world_landmarks else []
        confidence = sum(landmarks[i]["visibility"] for i in (11, 12, 23, 24, 25, 26)) / 6 if landmarks else 0.0
        pose_valid = bool(landmarks and confidence >= 0.5)
        hip_y, knee, tilt, speed, drop, depth_rel = 0.0, 180.0, 0.0, 0.0, 0.0, float(np.median(depth))
        if pose_valid:
            # Smooth coordinates after actual model inference; retain unsmoothed results too.
            used = [dict(p) for p in landmarks]
            if self.previous_landmarks and self.previous_time is not None and time_ms - self.previous_time <= 500:
                for i, p in enumerate(used):
                    for axis in ("x", "y", "z"):
                        p[axis] = 0.6 * p[axis] + 0.4 * self.previous_landmarks[i][axis]
            hx, hip_y = (used[23]["x"] + used[24]["x"]) / 2, (used[23]["y"] + used[24]["y"]) / 2
            sx, sy = (used[11]["x"] + used[12]["x"]) / 2, (used[11]["y"] + used[12]["y"]) / 2
            tilt = math.degrees(math.atan2(abs(sx - hx), max(abs(sy - hip_y), 1e-6)))
            coords = world or used
            knee = min(self._angle(coords[23], coords[25], coords[27]), self._angle(coords[24], coords[26], coords[28]))
            if self.previous_hip is not None and time_ms > self.previous_time:
                seconds = (time_ms - self.previous_time) / 1000
                speed = math.hypot(hx - self.previous_hip[0], hip_y - self.previous_hip[1]) / seconds
                drop = (hip_y - self.previous_hip[1]) / seconds
            self.previous_hip, self.previous_time, self.previous_landmarks = (hx, hip_y), time_ms, used
            h, w = depth.shape
            x, y = round(hx * (w - 1)), round(hip_y * (h - 1))
            if 0 <= x < w and 0 <= y < h:
                depth_rel = float(np.median(depth[max(0,y-7):min(h,y+8),max(0,x-7):min(w,x+8)]))
            gesture = self.decode_gesture(used)
            joints_depth = [float(depth[min(h-1,max(0,round(p["y"]*(h-1)))), min(w-1,max(0,round(p["x"]*(w-1))))]) for p in used]
        else:
            used, joints_depth, gesture = [], [], "NONE"
            self.previous_hip, self.previous_time, self.previous_landmarks = None, None, None
        evidence = pose_valid and ((tilt > 60 and hip_y > 0.55) or (drop > 0.65 and knee < 115 and hip_y > 0.5))
        return {"depth_raw": raw, "depth_relative": depth, "depth_valid": depth_valid,
                "pose_valid": pose_valid, "pose_confidence": confidence, "depth_rel": depth_rel,
                "hip_y": hip_y, "knee_deg": knee, "torso_tilt_deg": tilt, "motion_speed": speed,
                "abnormal_evidence": bool(evidence), "gesture": gesture,
                "landmarks": landmarks, "world_landmarks": world, "smoothed_landmarks": used,
                "joint_relative_inverse_depth": joints_depth,
                "depth_processing_ms": (depth_end - start) * 1000,
                "pose_processing_ms": (pose_end - depth_end) * 1000,
                "vision_processing_ms": (pose_end - start) * 1000}

    def close(self) -> None:
        self.pose.close()

