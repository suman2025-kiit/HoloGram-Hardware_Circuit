"""Bounded, atomic public downloads with byte provenance; no credentials required."""

from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(url: str, dest: Path, *, max_bytes: int = 300_000_000,
             expected_sha256: str | None = None, retries: int = 2) -> dict:
    """Use HTTPS, retain a completed cached file, and never retain a partial download."""
    if not url.startswith("https://"):
        raise ValueError("Only HTTPS downloads are supported")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        digest = sha256(dest)
        if expected_sha256 and digest != expected_sha256:
            raise ValueError(f"Checksum mismatch for existing {dest}; remove it to retry")
        return {"file": dest.name, "url": url, "bytes": dest.stat().st_size,
                "sha256": digest, "cached": True}
    partial = dest.with_name(dest.name + ".part")
    last_error = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "H-Learning-research/0.1"})
            with urllib.request.urlopen(req, timeout=45) as response, partial.open("wb") as out:
                total = 0
                while chunk := response.read(1024 * 1024):
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError(f"Download exceeds {max_bytes} bytes: {url}")
                    out.write(chunk)
                final_url = response.geturl()
                mime = response.headers.get("Content-Type", "")
            if total == 0:
                raise ValueError("Empty download")
            if "text/html" in mime and dest.suffix in {".csv", ".zip", ".onnx", ".task", ".mp4"}:
                raise ValueError(f"Server returned HTML instead of {dest.name}")
            digest = sha256(partial)
            if expected_sha256 and digest != expected_sha256:
                raise ValueError(f"Checksum mismatch: {dest.name}")
            os.replace(partial, dest)
            return {"file": dest.name, "url": url, "resolved_url": final_url,
                    "bytes": total, "sha256": digest,
                    "downloaded_utc": datetime.now(timezone.utc).isoformat(), "cached": False}
        except Exception as exc:
            partial.unlink(missing_ok=True)
            last_error = exc
            if attempt < retries:
                time.sleep(min(2 ** attempt, 4))
    raise RuntimeError(f"Download failed for {url}: {last_error}") from last_error


def save_manifest(path: Path, records: list[dict], **metadata) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({**metadata, "files": records}, indent=2) + "\n", encoding="utf-8")

