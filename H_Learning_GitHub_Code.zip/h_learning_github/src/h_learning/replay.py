"""Replay controller signals and generate explicitly synthetic regression vectors."""

from __future__ import annotations

import time
from dataclasses import replace
from pathlib import Path

from .controller import Controller, ControllerConfig
from .signals import FrameSignals, read_signals, write_csv, write_json
from .validation import session_report


def replay(path: Path, out: Path, config: ControllerConfig | None = None) -> dict:
    controller = Controller(config)
    rows = []
    for signal in read_signals(path):
        begin = time.perf_counter()
        result = controller.step(signal)
        row = {**signal.as_dict(),**result.as_dict()}
        row["controller_replay_us"] = (time.perf_counter()-begin)*1e6
        rows.append(row)
    write_csv(out/"trace.csv",rows)
    report = session_report(rows)
    report["run_type"] = "controller_replay"
    report["note"] = "Any processing_ms carried in input is inherited acquisition evidence, not neural inference rerun time. Controller replay is separately timed in microseconds."
    write_json(out/"report.json",report)
    return report


def demo(out: Path) -> dict:
    signals = []
    for i in range(110):
        event, answer, mode, cancel, reset = "NONE", "", 1, False, False
        if 10 <= i <= 16: event = "SELECT"
        if 20 <= i <= 25: event = "ROTATE_RIGHT"
        if 28 <= i <= 33: event = "ZOOM_IN"
        if 35 <= i <= 41: event,answer = "ANSWER","C"
        if 45 <= i <= 51: event = "NEXT"
        if 54 <= i <= 60: event,answer = "ANSWER","A"
        if 63 <= i <= 69: event = "NEXT"
        if i == 73: cancel = True
        if i >= 80: mode = 0
        if i == 103: reset = True
        valid = not (22 <= i <= 23)
        s = FrameSignals(frame_id=i+1,time_ms=i*50.0,mode=mode,start=i==0,
                         reset=reset,cancel=cancel,depth_valid=True,pose_valid=valid,
                         depth_frame_id=i+1,pose_frame_id=i+1,depth_time_ms=i*50.,pose_time_ms=i*50.,
                         depth_rel=0.5,pose_confidence=0.95 if valid else 0,
                         gesture=event,answer=answer,abnormal_evidence=90<=i<=102,
                         source_kind="synthetic_test_vector",command_source="script",sequence="logic_demo")
        # An intentionally stale pose ID tests same-frame pairing.
        if i == 30: s = replace(s,pose_frame_id=i)
        signals.append(s.as_dict())
    write_csv(out/"synthetic_signals.csv",signals)
    return replay(out/"synthetic_signals.csv",out)

