"""SSIM and metric PCK utilities requiring independently supplied ground truth."""

from __future__ import annotations


def pck(prediction, truth, valid=None, *, threshold_m=0.1) -> dict:
    import numpy as np
    pred,gt=np.asarray(prediction,float),np.asarray(truth,float)
    if pred.shape!=gt.shape or pred.ndim<2 or pred.shape[-1]!=3:
        raise ValueError("PCK expects equal (..., joints, 3) arrays in metres")
    if threshold_m<=0: raise ValueError("Metric threshold must be positive")
    mask=np.isfinite(gt).all(axis=-1)
    if valid is not None:
        if np.shape(valid)!=mask.shape: raise ValueError("Visibility mask shape mismatch")
        mask &= np.asarray(valid,bool)
    if not mask.any(): raise ValueError("No valid independently annotated keypoints")
    present=np.isfinite(pred).all(axis=-1)[mask]
    error=np.linalg.norm(pred-gt,axis=-1)[mask]
    error[~present]=np.inf
    return {"valid_keypoints":int(mask.sum()),"threshold_m":threshold_m,
            "pck":float((error<=threshold_m).mean()),"missing_predictions":int((~present).sum()),
            "mean_finite_prediction_error_m":float(error[present].mean()) if present.any() else None,
            "alignment":"No automatic scale, rotation or translation alignment"}


def ssim(prediction, truth, *, data_range: float) -> float:
    import numpy as np
    from scipy.ndimage import gaussian_filter
    x,y=np.asarray(prediction,float),np.asarray(truth,float)
    if x.shape!=y.shape or x.ndim!=2 or min(x.shape)<11:
        raise ValueError("SSIM expects equal 2D images at least 11x11 pixels")
    if data_range<=0 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Finite images and a positive declared data range are required")
    ux,uy=gaussian_filter(x,1.5,truncate=3.5),gaussian_filter(y,1.5,truncate=3.5)
    vx=gaussian_filter(x*x,1.5,truncate=3.5)-ux*ux
    vy=gaussian_filter(y*y,1.5,truncate=3.5)-uy*uy
    cov=gaussian_filter(x*y,1.5,truncate=3.5)-ux*uy
    c1,c2=(.01*data_range)**2,(.03*data_range)**2
    score=((2*ux*uy+c1)*(2*cov+c2))/((ux*ux+uy*uy+c1)*(vx+vy+c2))
    return float(score[5:-5,5:-5].mean())
