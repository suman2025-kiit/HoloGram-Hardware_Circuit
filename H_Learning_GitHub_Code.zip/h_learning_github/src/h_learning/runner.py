"""Execute neural inference, controller updates, and honest session logging."""

from __future__ import annotations

import csv
import importlib.metadata
import json
import platform
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .acquisition import frames
from .controller import Controller, ControllerConfig
from .display import KEYS, draw
from .downloads import sha256
from .signals import FrameSignals, write_json
from .vision import VisionPipeline


def run(args) -> dict:
    import cv2
    import numpy as np
    args.out.mkdir(parents=True, exist_ok=True)
    if any(args.out.iterdir()):
        raise FileExistsError(f"Session directory must be empty: {args.out}")
    source_kind = "live_camera" if args.camera is not None else "recorded_urfall_rgb" if args.urfall_dir else "recorded_video"
    lessons = json.loads(args.lessons.read_text())
    config = ControllerConfig.load(args.config)
    controller = Controller(config, tuple(lesson["answer"] for lesson in lessons))
    versions = {}
    for name in ("numpy", "mediapipe", "opencv-contrib-python"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = "not resolved"
    metadata = {
        "schema_version": "1.0", "started_utc": datetime.now(timezone.utc).isoformat(),
        "source_kind": source_kind, "sequence": args.sequence, "video": str(args.video or ""),
        "camera": args.camera, "participant_id": args.participant_id, "input_condition": args.input,
        "hardware": platform.platform(), "python": platform.python_version(), "versions": versions,
        "model_sha256": {p.name: sha256(p) for p in (args.models/"model-small.onnx",args.models/"pose_landmarker_lite.task")},
        "controller_config": asdict(config), "threads": args.threads, "smoothing_alpha": args.smoothing,
        "timestamps": "Official camera-0 synchronization CSV" if args.urfall_dir else
                      "Software time after camera read, not physical exposure time" if args.camera is not None else
                      "Decoder timestamps, with frame-rate fallback when unavailable",
        "depth_units": "relative inverse depth, not metres", "pose_units": "normalized image and estimated hip-relative metres",
        "processing_time": "Serial vision and controller wall time, excludes display/disk and sensor exposure; warm-up included",
        "record_frames": args.record_frames,
    }
    write_json(args.out/"metadata.json", metadata)
    pipeline = None
    rows = []
    mouse_commands = []
    window = "H-Learning execution"
    if not args.headless:
        cv2.namedWindow(window, cv2.WINDOW_NORMAL)
        def mouse(event, x, y, flags, param):
            if args.input == "mouse" and event == cv2.EVENT_LBUTTONDOWN:
                mouse_commands.append("SELECT")
            elif event == cv2.EVENT_RBUTTONDOWN:
                mouse_commands.append("CANCEL")
        cv2.setMouseCallback(window, mouse)
    mode, first, request_start, was_alert = args.mode, True, True, False
    try:
        pipeline = VisionPipeline(args.models, threads=args.threads, smoothing=args.smoothing)
        with (args.out/"signals.csv").open("w", newline="", encoding="utf-8") as signal_file, \
             (args.out/"trace.csv").open("w", newline="", encoding="utf-8") as trace_file, \
             (args.out/"pose.jsonl").open("w", encoding="utf-8") as pose_file:
            signal_writer, trace_writer = None, None
            start_wall = time.perf_counter()
            for frame_id, timestamp, image, capture_utc, label in frames(
                    camera=args.camera, video=args.video, urfall_dir=args.urfall_dir,
                    sequence=args.sequence, max_frames=args.max_frames):
                begin = time.perf_counter()
                inference = pipeline.infer(image, timestamp)
                key = -1 if args.headless else cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    break
                cancel, reset, answer = key == ord("x"), key == ord("r"), ""
                if key == ord("t"):
                    mode = 1 - mode
                event = inference["gesture"] if args.input == "gesture" else "NONE"
                command_source = args.input
                if key in KEYS and (args.input in {"keyboard", "mouse"} or KEYS[key] == "ANSWER"):
                    event, command_source = KEYS[key], "keyboard"
                    if event == "ANSWER":
                        answer = {ord("1"):"A", ord("2"):"B", ord("3"):"C"}[key]
                if mouse_commands:
                    event, command_source = mouse_commands.pop(0), "mouse"
                cancel = cancel or event == "CANCEL" or (args.input == "gesture" and inference["gesture"] == "CANCEL")
                signal = FrameSignals(
                    frame_id=frame_id, time_ms=timestamp, mode=mode, start=request_start,
                    reset=reset, cancel=cancel, depth_valid=inference["depth_valid"], pose_valid=inference["pose_valid"],
                    depth_frame_id=frame_id, pose_frame_id=frame_id, depth_time_ms=timestamp, pose_time_ms=timestamp,
                    depth_rel=inference["depth_rel"], pose_confidence=inference["pose_confidence"],
                    hip_y=inference["hip_y"], knee_deg=inference["knee_deg"], torso_tilt_deg=inference["torso_tilt_deg"],
                    motion_speed=inference["motion_speed"], abnormal_evidence=inference["abnormal_evidence"], gesture=event,
                    answer=answer, command_source=command_source, source_kind=source_kind, sequence=args.sequence,
                    gt_label=label, capture_utc=capture_utc, processing_ms=inference["vision_processing_ms"],
                    depth_processing_ms=inference["depth_processing_ms"], pose_processing_ms=inference["pose_processing_ms"],
                )
                decision = controller.step(signal)
                processing_ms = (time.perf_counter() - begin) * 1000
                signal_row = signal.as_dict()
                signal_row["processing_ms"] = processing_ms
                trace_row = {**signal_row, **decision.as_dict()}
                if first:
                    signal_writer = csv.DictWriter(signal_file, fieldnames=list(signal_row))
                    trace_writer = csv.DictWriter(trace_file, fieldnames=list(trace_row))
                    signal_writer.writeheader(); trace_writer.writeheader()
                    first = False
                signal_writer.writerow(signal_row)
                trace_writer.writerow(trace_row)
                pose_file.write(json.dumps({"frame_id":frame_id, "time_ms":timestamp,
                                          **{k:inference[k] for k in ("landmarks","world_landmarks","smoothed_landmarks","joint_relative_inverse_depth")}})+"\n")
                rows.append(trace_row)
                # Cancellation has priority even on the first frame. Keep the
                # activation request pending until the controller accepts it.
                request_start = not controller.running
                if args.record_frames:
                    (args.out/"frames").mkdir(exist_ok=True)
                    if not cv2.imwrite(str(args.out/"frames"/f"{frame_id:06d}.jpg"), image):
                        raise OSError("Could not save camera image")
                    (args.out/"depth").mkdir(exist_ok=True)
                    np.savez_compressed(args.out/"depth"/f"{frame_id:06d}.npz",
                                        raw_inverse_depth=inference["depth_raw"], relative_inverse_depth=inference["depth_relative"])
                if not args.headless or args.save_views:
                    view = draw(image, inference, decision, mode, lessons)
                    if not args.headless:
                        cv2.imshow(window, view)
                    if args.save_views and (len(rows) == 1 or len(rows) % args.view_every == 0 or decision.command or (decision.alert and not was_alert)):
                        (args.out/"views").mkdir(exist_ok=True)
                        if not cv2.imwrite(str(args.out/"views"/f"{frame_id:06d}.jpg"), view):
                            raise OSError("Could not save execution view")
                was_alert = decision.alert
            elapsed = time.perf_counter() - start_wall
        if not rows:
            raise RuntimeError("No frames were processed")
        from .validation import session_report
        report = session_report(rows)
        report["wall_elapsed_s"] = elapsed
        report["wall_throughput_fps_including_io"] = len(rows)/elapsed
        report["status"] = "completed"
        write_json(args.out/"report.json", report)
        metadata["status"] = "completed"
        metadata["finished_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(args.out/"metadata.json", metadata)
        return report
    except BaseException as exc:
        metadata["status"], metadata["error"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed", str(exc)
        write_json(args.out/"metadata.json", metadata)
        raise
    finally:
        if pipeline is not None:
            pipeline.close()
        if not args.headless:
            cv2.destroyAllWindows()
