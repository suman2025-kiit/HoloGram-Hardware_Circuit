"""Camera/video/official PNG-sequence acquisition; recorded timestamps are preserved."""

from __future__ import annotations

import csv
import re
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path


def timestamps(path: Path) -> dict[int, float]:
    with path.open(newline="", encoding="utf-8") as stream:
        return {int(row[0]): float(row[1]) for row in csv.reader(stream) if row}


def urfall_labels(directory: Path, sequence: str) -> dict[int, str]:
    file = directory / ("urfall-cam0-falls.csv" if sequence.startswith("fall-") else "urfall-cam0-adls.csv")
    if not file.is_file():
        return {}
    with file.open(newline="", encoding="utf-8") as stream:
        return {int(row[1]): row[2] for row in csv.reader(stream) if row and row[0] == sequence}


def frames(*, camera: int | None = None, video: Path | None = None,
           urfall_dir: Path | None = None, sequence: str = "", max_frames: int = 0):
    import cv2
    import numpy as np
    if urfall_dir:
        times = timestamps(urfall_dir / (sequence + "-data.csv"))
        labels = urfall_labels(urfall_dir, sequence)
        with zipfile.ZipFile(urfall_dir / (sequence + "-cam0-rgb.zip")) as rgb:
            names = [n for n in rgb.namelist() if n.lower().endswith(".png")]
            indexed = sorted((int(re.search(r"-(\d+)\.png$", n).group(1)), n) for n in names)
            for i, (frame_id, name) in enumerate(indexed):
                if max_frames and i >= max_frames:
                    break
                if frame_id not in times:
                    raise ValueError(f"No recorded timestamp for frame {frame_id}")
                image = cv2.imdecode(np.frombuffer(rgb.read(name), np.uint8), cv2.IMREAD_COLOR)
                if image is None:
                    raise ValueError(f"Cannot decode {name}")
                yield frame_id, times[frame_id], image, "", labels.get(frame_id, "")
        return
    cap = cv2.VideoCapture(camera if camera is not None else str(video))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open {'camera ' + str(camera) if camera is not None else video}")
    origin = time.perf_counter()
    last_time = -1.0
    fps = cap.get(cv2.CAP_PROP_FPS)
    try:
        frame_id = 0
        while not max_frames or frame_id < max_frames:
            ok, image = cap.read()
            if not ok:
                break
            frame_id += 1
            if camera is not None:
                t = (time.perf_counter() - origin) * 1000
                capture_utc = datetime.now(timezone.utc).isoformat()
            else:
                # Decoder timestamp if available; FPS-derived times are disclosed in metadata.
                t = float(cap.get(cv2.CAP_PROP_POS_MSEC))
                if t <= last_time:
                    if fps <= 0:
                        raise ValueError("Video has no usable timestamps or frame rate")
                    t = (frame_id - 1) * 1000 / fps
                capture_utc = ""
            if t <= last_time:
                raise ValueError("Source timestamps do not increase strictly")
            last_time = t
            yield frame_id, t, image, capture_utc, ""
    finally:
        cap.release()

