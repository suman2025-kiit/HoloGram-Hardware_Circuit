"""Command-line entry point. Run from the repository root for default paths."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(prog="h-learning",description="Depth-pose dual-mode control, actual inference and recorded-data validation")
    sub = parser.add_subparsers(dest="command",required=True)
    p = sub.add_parser("demo",help="Synthetic controller regression, clearly labelled")
    p.add_argument("--out",type=Path,default=Path("runs/demo"))
    p = sub.add_parser("replay",help="Run the FSM on a frame-signal CSV")
    p.add_argument("input",type=Path); p.add_argument("--out",type=Path,required=True); p.add_argument("--config",type=Path)
    p = sub.add_parser("prepare-urfall",help="Join official depth features to recorded timestamps")
    p.add_argument("--data",type=Path,default=Path("data/urfall")); p.add_argument("--out",type=Path,default=Path("data/processed/urfall_recorded_features.csv"))
    p = sub.add_parser("urfall-baseline",help="Depth-only reference benchmark; not two-network inference")
    p.add_argument("--data",type=Path,default=Path("data/processed/urfall_recorded_features.csv")); p.add_argument("--out",type=Path,default=Path("runs/urfall_baseline"))
    p.add_argument("--hold-ms",type=float,default=250.0)
    p = sub.add_parser("plot",help="Export Figures 3-6 as JPEG plots from logs")
    p.add_argument("input",type=Path); p.add_argument("--out",type=Path,required=True)
    p = sub.add_parser("run",help="Execute actual MiDaS and BlazePose inference")
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--camera",type=int); source.add_argument("--video",type=Path); source.add_argument("--urfall-dir",type=Path)
    p.add_argument("--sequence",default="")
    p.add_argument("--out",type=Path,required=True); p.add_argument("--models",type=Path,default=Path("models"))
    p.add_argument("--config",type=Path,default=Path("config/controller.json")); p.add_argument("--lessons",type=Path,default=Path("config/lessons.json"))
    p.add_argument("--mode",type=int,choices=(0,1),default=1); p.add_argument("--input",choices=("gesture","keyboard","mouse"),default="gesture")
    p.add_argument("--participant-id",default=""); p.add_argument("--headless",action="store_true")
    p.add_argument("--record-frames",action="store_true"); p.add_argument("--save-views",action="store_true")
    p.add_argument("--view-every",type=int,default=30); p.add_argument("--max-frames",type=int,default=0)
    p.add_argument("--threads",type=int,default=2); p.add_argument("--smoothing",type=float,default=0.25)
    args = parser.parse_args()
    if args.command == "demo":
        from .replay import demo
        result = demo(args.out)
    elif args.command == "replay":
        from .replay import replay
        from .controller import ControllerConfig
        result = replay(args.input,args.out,ControllerConfig.load(args.config))
    elif args.command == "prepare-urfall":
        from .datasets import prepare_urfall
        result = prepare_urfall(args.data,args.out)
    elif args.command == "urfall-baseline":
        if args.hold_ms < 0: parser.error("--hold-ms must be non-negative")
        from .datasets import depth_baseline
        result = depth_baseline(args.data,args.out,hold_ms=args.hold_ms)
    elif args.command == "plot":
        from .plots import plot_trace
        result = plot_trace(args.input,args.out)
    else:
        if args.urfall_dir and not args.sequence: parser.error("--sequence is required with --urfall-dir")
        if args.view_every <= 0 or args.max_frames < 0: parser.error("Invalid frame count")
        from .runner import run
        result = run(args)
    print(json.dumps(result,indent=2,allow_nan=False))


if __name__ == "__main__":
    main()

