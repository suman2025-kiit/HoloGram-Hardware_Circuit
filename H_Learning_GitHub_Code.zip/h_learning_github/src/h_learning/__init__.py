"""H-Learning reference implementation. See README.md for evidence boundaries."""

__version__ = "0.1.0"

