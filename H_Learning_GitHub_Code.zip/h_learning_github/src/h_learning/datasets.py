"""Official depth-feature adapter; no pose values or timestamps are fabricated."""

from __future__ import annotations

import csv
import math
from collections import Counter, defaultdict
from pathlib import Path

from .acquisition import timestamps
from .downloads import sha256
from .signals import write_csv, write_json
from .validation import binary_metrics

FEATURES = ["height_width_ratio","major_minor_ratio","bbox_occupancy","max_std_xz",
            "height_to_standing_ratio","height_mm","centre_floor_distance_mm","p40"]


def split(sequence: str) -> str:
    kind, index = sequence.split("-")
    i = int(index)
    a,b = (18,24) if kind == "fall" else (24,32)
    return "train" if i <= a else "validation" if i <= b else "test"


def prepare_urfall(directory: Path, out: Path) -> dict:
    rows, issues, cache = [], [], {}
    for filename in ("urfall-cam0-falls.csv", "urfall-cam0-adls.csv"):
        with (directory/filename).open(newline="", encoding="utf-8") as stream:
            for line, raw in enumerate(csv.reader(stream), 1):
                if len(raw) != 11:
                    raise ValueError(f"{filename}:{line}: Expected 11 official columns")
                sequence, frame, label = raw[0], int(raw[1]), int(raw[2])
                if label not in (-1,0,1):
                    raise ValueError(f"Unknown posture label: {label}")
                if sequence not in cache:
                    cache[sequence] = timestamps(directory/(sequence+"-data.csv"))
                if frame not in cache[sequence]:
                    issues.append({"sequence":sequence,"frame":frame,"reason":"missing recorded timestamp"})
                    continue
                values = list(map(float, raw[3:]))
                if not all(math.isfinite(v) for v in values):
                    raise ValueError(f"Non-finite feature at {filename}:{line}")
                rows.append({"sequence":sequence,"frame_id":frame,"time_ms":cache[sequence][frame],
                             "posture_label":label, **dict(zip(FEATURES,values)),
                             "split":split(sequence),"source_kind":"recorded_urfall_depth_features"})
    rows.sort(key=lambda r:(r["sequence"],r["frame_id"]))
    for sequence in cache:
        series = [r for r in rows if r["sequence"] == sequence]
        if any(b["time_ms"] <= a["time_ms"] for a,b in zip(series,series[1:])):
            raise ValueError(f"Non-increasing recorded timestamps in {sequence}")
    write_csv(out,rows)
    report = {"dataset":"UR Fall Detection Dataset", "rows":len(rows),"sequences":len(cache),
              "posture_label_counts":dict(Counter(r["posture_label"] for r in rows)),
              "split_rows":dict(Counter(r["split"] for r in rows)),
              "split_sequences":dict(Counter(split(s) for s in cache)),
              "timestamp_join_issues":issues, "output_sha256":sha256(out),
              "licence":"CC-BY-NC-SA-4.0", "source_page":"https://fenix.ur.edu.pl/mkepski/ds/uf.html",
              "transformation":"Added recorded camera-0 time by exact sequence/frame join and a deterministic sequence split; original numerical features and posture labels retained.",
              "limits":"Depth-feature data are not MiDaS/BlazePose predictions. Sequence split is not guaranteed participant-disjoint. No educational outcomes or pose ground truth supplied."}
    write_json(out.with_suffix(".manifest.json"),report)
    return report


def depth_baseline(path: Path, out_dir: Path, *, hold_ms: float = 250.0) -> dict:
    """A deliberately simple reference detector on real Kinect-derived features.

    Distinct from the full two-network pipeline, with fixed thresholds, no label
    access in the detector, and a minimum two-sample temporal confirmation.
    """
    groups = defaultdict(list)
    with path.open(newline="",encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            groups[row["sequence"]].append(row)
    trace, sequence_rows = [], []
    by_split = defaultdict(lambda:([],[]))
    for sequence, rows in sorted(groups.items()):
        since, count, last_time, latched = None, 0, None, False
        first_alert, first_lying = None, None
        for row in rows:
            t = float(row["time_ms"])
            evidence = (float(row["height_width_ratio"]) < 1.25
                        and float(row["height_to_standing_ratio"]) < 0.65
                        and float(row["centre_floor_distance_mm"]) < 650
                        and float(row["p40"]) > 0.15)
            if last_time is not None and t-last_time > 500:
                since,count = None,0
            if evidence:
                if since is None:
                    since,count = t,0
                count += 1
                if count >= 2 and t-since >= hold_ms:
                    latched = True
            else:
                since,count = None,0
            last_time = t
            label = int(row["posture_label"])
            if latched and first_alert is None:
                first_alert = t
            if label == 1 and first_lying is None:
                first_lying = t
            trace.append({**row,"evidence":evidence,"baseline_alert":latched})
            if label in (-1,1):
                gt,pred = by_split[row["split"]]
                gt.append(label == 1); pred.append(latched)
        sequence_rows.append({"sequence":sequence,"split":split(sequence),"is_fall_sequence":sequence.startswith("fall-"),
                              "any_baseline_alert":latched,"first_alert_ms":first_alert,"first_lying_label_ms":first_lying,
                              "alert_minus_first_lying_ms":first_alert-first_lying if first_alert is not None and first_lying is not None else None})
    write_csv(out_dir/"depth_baseline_trace.csv",trace)
    write_csv(out_dir/"sequence_results.csv",sequence_rows)
    report = {"implementation":"Fixed-threshold Kinect depth-feature baseline, not full H-Learning neural inference",
              "rows":len(trace),"sequences":len(groups),"input_sha256":sha256(path),
              "thresholds":{"height_width_ratio_lt":1.25,"height_to_standing_ratio_lt":0.65,
                            "centre_floor_distance_mm_lt":650,"p40_gt":0.15,"hold_ms":hold_ms,"min_samples":2},
              "lying_posture_frame_metrics":{name:binary_metrics(gt,pred) for name,(gt,pred) in by_split.items()},
              "fall_sequence_any_alert_metrics":{name:binary_metrics([bool(r["is_fall_sequence"]) for r in sequence_rows if r["split"]==name],
                                                                    [bool(r["any_baseline_alert"]) for r in sequence_rows if r["split"]==name]) for name in ("train","validation","test")},
              "limitations":"ADL clips can contain intentional lying, so posture is not evidence of a fall or fraud. No thresholds fitted on test sequences. This is a reference benchmark, not the paper's claimed accuracy."}
    write_json(out_dir/"report.json",report)
    return report

