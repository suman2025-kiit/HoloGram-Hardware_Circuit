"""Versioned frame-level interface shared by acquisition, replay, and export."""

from __future__ import annotations

import csv
import json
import math
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Iterator


@dataclass(frozen=True)
class FrameSignals:
    frame_id: int
    time_ms: float
    mode: int = 1
    start: bool = False
    reset: bool = False
    cancel: bool = False
    depth_valid: bool = False
    pose_valid: bool = False
    depth_frame_id: int = -1
    pose_frame_id: int = -1
    depth_time_ms: float = 0.0
    pose_time_ms: float = 0.0
    depth_rel: float = 0.0
    pose_confidence: float = 0.0
    hip_y: float = 0.0
    knee_deg: float = 180.0
    torso_tilt_deg: float = 0.0
    motion_speed: float = 0.0
    abnormal_evidence: bool = False
    gesture: str = "NONE"
    answer: str = ""
    lesson_ready: bool = True
    command_source: str = "gesture"
    source_kind: str = "unspecified"
    sequence: str = ""
    gt_label: str = ""
    processing_ms: float = 0.0
    depth_processing_ms: float = 0.0
    pose_processing_ms: float = 0.0
    capture_utc: str = ""

    def __post_init__(self) -> None:
        if self.mode not in (0, 1):
            raise ValueError("Mode must be 0 (monitoring) or 1 (learning)")
        if self.frame_id < 0 or not math.isfinite(self.time_ms) or self.time_ms < 0:
            raise ValueError("Frame IDs and timestamps must be non-negative")
        for field in fields(self):
            value = getattr(self, field.name)
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"Non-finite {field.name}")
        if not 0 <= self.pose_confidence <= 1 or not 0 <= self.depth_rel <= 1:
            raise ValueError("pose_confidence and depth_rel must lie in [0,1]")
        if self.command_source not in {"gesture", "keyboard", "mouse", "script"}:
            raise ValueError("Unknown command_source")

    def as_dict(self) -> dict:
        return asdict(self)


BOOL_FIELDS = {"start", "reset", "cancel", "depth_valid", "pose_valid", "abnormal_evidence", "lesson_ready"}
INT_FIELDS = {"frame_id", "mode", "depth_frame_id", "pose_frame_id"}
FLOAT_FIELDS = {f.name for f in fields(FrameSignals) if f.type in {float, "float"}}


def parse_bool(value: object) -> bool:
    if str(value).lower() in {"1", "true"}:
        return True
    if str(value).lower() in {"0", "false"}:
        return False
    raise ValueError(f"Expected 0/1 or true/false; got {value!r}")


def read_signals(path: Path) -> Iterator[FrameSignals]:
    allowed = {f.name for f in fields(FrameSignals)}
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        if not {"frame_id", "time_ms"} <= set(reader.fieldnames or []):
            raise ValueError("Input CSV must contain frame_id and time_ms")
        for line, row in enumerate(reader, 2):
            try:
                clean = {}
                for key, value in row.items():
                    if key not in allowed or value in (None, ""):
                        continue
                    clean[key] = (parse_bool(value) if key in BOOL_FIELDS else
                                  int(value) if key in INT_FIELDS else
                                  float(value) if key in FLOAT_FIELDS else value)
                yield FrameSignals(**clean)
            except (ValueError, TypeError) as exc:
                raise ValueError(f"{path}:{line}: {exc}") from exc


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("Cannot write an empty CSV")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")

