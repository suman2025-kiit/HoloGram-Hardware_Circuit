# Recorded dataset terms and attribution

The official **UR Fall Detection Dataset** is provided by Michał Kępski,
University of Rzeszow, and associated with the work of Bogdan Kwolek and
Michał Kępski. Source: https://fenix.ur.edu.pl/mkepski/ds/uf.html

The provider licenses this work under **Creative Commons
Attribution–NonCommercial–ShareAlike 4.0 International (CC BY-NC-SA 4.0)**:
https://creativecommons.org/licenses/by-nc-sa/4.0/
Legal terms: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode

Cite: B. Kwolek and M. Kepski, “Human fall detection on embedded platform
using depth maps and wireless accelerometer,” *Computer Methods and Programs
in Biomedicine*, vol. 117, no. 3, pp. 489–501, 2014.

Original CSV, PNG archives and MP4 previews are redistributed unchanged.
`data/processed/urfall_recorded_features.csv` adds recorded timestamps,
column names, source tags and a sequence-level split. Twenty rows without
matching timing records are excluded from that derivative, as listed in its
manifest. Original rows remain in the unmodified source files.

Redistributed recorded data, transformed data and examples derived from those
recordings retain CC BY-NC-SA 4.0. Attribution to the provider, the source link,
the licence link and notices of modifications must accompany redistribution.
The MIT code licence does not replace these data terms. For uses outside the
provider's stated noncommercial academic use, contact the provider through
the official dataset page.

