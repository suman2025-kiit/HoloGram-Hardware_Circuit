#!/usr/bin/env python3
"""Fetch the official MiDaS v2.1 small ONNX and MediaPipe Pose Landmarker lite."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from h_learning.downloads import download, save_manifest

MODELS = {
    "model-small.onnx": "https://github.com/isl-org/MiDaS/releases/download/v2_1/model-small.onnx",
    "pose_landmarker_lite.task": "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "models")
    args = parser.parse_args()
    lock_file = ROOT / "models" / "checksums.json"
    import json
    locked = json.loads(lock_file.read_text()) if lock_file.exists() else {}
    entries = []
    for name, url in MODELS.items():
        result = download(url, args.out / name, expected_sha256=locked.get(name))
        entries.append(result)
        print(f"{name}: {result['bytes']} bytes, SHA256 {result['sha256']}")
    save_manifest(args.out / "download_manifest.json", entries,
                  models="MiDaS v2.1 small and BlazePose/GHUM Pose Landmarker lite",
                  note="External weights; see THIRD_PARTY.md. Not trained by H-Learning.")


if __name__ == "__main__":
    main()

