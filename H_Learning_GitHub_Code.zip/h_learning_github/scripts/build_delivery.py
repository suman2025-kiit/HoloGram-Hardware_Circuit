#!/usr/bin/env python3
"""Build reproducible GitHub/source and recorded-data archives without user sessions."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.downloads import sha256
from h_learning.signals import write_json


def add_file(archive:zipfile.ZipFile,path:Path,name:str):
    # Raw recording ZIPs and MP4s are already compressed.
    archive.write(path,name,compress_type=zipfile.ZIP_STORED if path.suffix in {".zip",".mp4"} else zipfile.ZIP_DEFLATED)


def is_temporary(path:Path):
    return path.name.endswith((".part", ".tmp", ".temp")) or any(
        part.startswith(".") and part not in {".github", ".gitignore"}
        for part in path.relative_to(ROOT).parts
    )


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,required=True)
    a=parser.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    sources=[]
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or is_temporary(p):continue
        relative=p.relative_to(ROOT)
        if p.resolve().is_relative_to(a.out.resolve()):continue
        if any(part in {".git",".venv","__pycache__","build","dist","runs"} or part.endswith(".egg-info") for part in relative.parts):continue
        if p.suffix in {".pyc",".vvp",".onnx",".task"}:continue
        if relative.parts[0]=="models" and p.name=="download_manifest.json":continue
        if relative.parts[:2]==("data","urfall") and p.suffix==".zip":continue
        sources.append(p)
    code=a.out/"H_Learning_GitHub_Code.zip"
    with zipfile.ZipFile(code,"w") as archive:
        for p in sources:add_file(archive,p,"h_learning_github/"+p.relative_to(ROOT).as_posix())
    dataset=a.out/"H_Learning_Recorded_Validation_Data.zip"
    data_files=sorted(p for folder in (ROOT/"data"/"urfall",ROOT/"data"/"processed") for p in folder.rglob("*") if p.is_file() and not is_temporary(p))
    data_files += [ROOT/"data"/"DATA_LICENSE.md",ROOT/"docs"/"DATASET_CARD.md"]
    with zipfile.ZipFile(dataset,"w") as archive:
        for p in data_files:add_file(archive,p,p.relative_to(ROOT).as_posix())
    readme=a.out/"README_H_Learning.md"
    shutil.copyfile(ROOT/"README.md",readme)
    report=a.out/"H_Learning_Validation_Report.md"
    shutil.copyfile(ROOT/"VALIDATION.md",report)
    outputs=[code,dataset,readme,report]
    for p in (code,dataset):
        with zipfile.ZipFile(p) as archive:
            bad=archive.testzip()
            if bad:raise ValueError(f"Corrupt archived member: {bad}")
    entries=[{"file":p.name,"bytes":p.stat().st_size,"sha256":sha256(p)} for p in outputs]
    write_json(a.out/"H_Learning_Delivery_Checksums.json",{"files":entries,"source_files_in_code_archive":len(sources),"recorded_data_files":len(data_files)})
    print(json.dumps(entries,indent=2))


if __name__=="__main__":main()
