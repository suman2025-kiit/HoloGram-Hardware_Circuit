#!/usr/bin/env python3
"""Compare issued commands with independent, manually annotated intention windows."""

import argparse
import csv
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.signals import write_csv,write_json
from h_learning.validation import percentile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace",type=Path); parser.add_argument("annotations",type=Path)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    with args.trace.open(newline="") as stream: trace=list(csv.DictReader(stream))
    with args.annotations.open(newline="") as stream: annotations=list(csv.DictReader(stream))
    if not annotations: parser.error("Annotate actual intended commands before evaluation; the template has no participant observations")
    commands=[(i,float(r["time_ms"]),r["command"]) for i,r in enumerate(trace) if r.get("command")]
    used=set();results=[];previous_end=-1
    for a in annotations:
        start,end=float(a["start_ms"]),float(a["end_ms"])
        if start>end or start<=previous_end: parser.error("Annotation windows must be ordered and non-overlapping")
        previous_end=end
        inside=[(i,t,c) for i,t,c in commands if start<=t<=end]
        wanted=a["expected_command"]
        matching=[(i,t,c) for i,t,c in inside if c==wanted]
        successful=not inside if wanted=="NONE" else bool(matching)
        used.update(i for i,t,c in inside)
        results.append({**a,"success":successful,"issued_commands":";".join(c for i,t,c in inside),
                        "extra_or_wrong_commands":len(inside)-(1 if matching else 0),
                        "confirmation_from_annotation_ms":matching[0][1]-start if matching else None})
    delays=[r["confirmation_from_annotation_ms"] for r in results if r["confirmation_from_annotation_ms"] is not None]
    write_csv(args.out/"task_results.csv",results)
    report={"annotated_windows":len(results),"successful_windows":sum(r["success"] for r in results),
            "window_success_rate":sum(r["success"] for r in results)/len(results),
            "commands_outside_annotated_windows":sum(i not in used for i,t,c in commands),
            "extra_or_wrong_commands":sum(r["extra_or_wrong_commands"] for r in results),
            "annotation_to_commit_ms":{"p50":percentile(delays,50),"p95":percentile(delays,95)},
            "scope":"Independent intention-window annotations in source time. Does not measure physical motion-to-photon latency or learning gains."}
    write_json(args.out/"report.json",report); print(report)


if __name__=="__main__": main()

