#!/usr/bin/env python3
"""Evaluate independently registered/annotated NPZ pairs. Never model-self ground truth."""
import argparse
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.signals import write_json
from h_learning.vision_metrics import pck,ssim


def main():
    import numpy as np
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pairs",type=Path,help="NPZ: pose_pred_m,pose_gt_m,pose_valid; or image_pred,image_gt")
    parser.add_argument("--metric",choices=("pck","ssim"),required=True)
    parser.add_argument("--threshold-m",type=float,default=.1)
    parser.add_argument("--data-range",type=float)
    parser.add_argument("--ground-truth-description",required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    with np.load(args.pairs,allow_pickle=False) as arrays:
        if args.metric=="pck":
            result=pck(arrays["pose_pred_m"],arrays["pose_gt_m"],arrays["pose_valid"] if "pose_valid" in arrays else None,threshold_m=args.threshold_m)
        else:
            if not args.data_range: parser.error("--data-range is required for SSIM")
            result={"ssim":ssim(arrays["image_pred"],arrays["image_gt"],data_range=args.data_range),"data_range":args.data_range}
    result["ground_truth_description"]=args.ground_truth_description
    result["scope"]="Supplied array pairs only; no automatic camera registration or metric-depth calibration"
    write_json(args.out,result)
    print(result)


if __name__=="__main__": main()

