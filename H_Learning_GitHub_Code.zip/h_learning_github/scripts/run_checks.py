#!/usr/bin/env python3
"""Retain real test/CLI/export verification results; optional vision runs are separate."""

import argparse
import csv
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.signals import write_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",type=Path,default=ROOT/"validation_runs"/"python_checks")
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    env={**os.environ,"PYTHONPATH":str(ROOT/"src")}
    test=subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-v"],cwd=ROOT,env=env,capture_output=True,text=True)
    log=test.stdout+test.stderr
    (a.out/"unittest.log").write_text(log)
    if test.returncode:raise RuntimeError(log)
    import re
    n=int(re.search(r"Ran (\d+) tests",log).group(1))
    with tempfile.TemporaryDirectory(prefix="h_learning_checks_") as temporary:
        work=Path(temporary)
        commands=[
            [sys.executable,"-m","h_learning","demo","--out",str(work/"demo")],
            [sys.executable,str(ROOT/"scripts"/"export_interfaces.py"),str(work/"demo"/"synthetic_signals.csv"),"--out",str(work/"interfaces")],
        ]
        for command in commands:
            r=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True)
            if r.returncode:raise RuntimeError(r.stdout+r.stderr)
        with (work/"interfaces"/"matlab_signals.csv").open(newline="") as f:
            rows=list(csv.DictReader(f))
        assert len(rows)==110
        for file in (work/"interfaces").glob("*.pwl"):
            pts=[tuple(map(float,line.split())) for line in file.read_text().splitlines()]
            assert all(b[0]>a0[0] for a0,b in zip(pts,pts[1:])),file
        demo=json.loads((work/"demo"/"report.json").read_text())
        assert not any(demo["invariant_violations"].values())
    report={"passed":True,"python_tests":n,"skipped_tests":log.count(" ... skipped "),
            "integration_checks":["110-sample controller CLI demo","MATLAB/PWL/WaveDrom export","PWL timestamp ordering","controller invariant report"],
            "note":"Synthetic interface/regression checks, not human or circuit simulator observations"}
    write_json(a.out/"report.json",report)
    print(log);print(report)


if __name__=="__main__":main()

