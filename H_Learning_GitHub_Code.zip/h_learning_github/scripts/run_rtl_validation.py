#!/usr/bin/env python3
"""Run the compact SystemVerilog testbench and retain simulator-generated evidence."""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.signals import write_json


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=ROOT/"runs"/"rtl")
    parser.add_argument("--iverilog",default=shutil.which("iverilog"))
    parser.add_argument("--vvp",default=shutil.which("vvp"))
    parser.add_argument("--ivl-dir",type=Path,help="Optional backend directory for a relocatable Icarus installation")
    args=parser.parse_args()
    if not args.iverilog or not args.vvp:
        parser.error("Install Icarus Verilog, or specify --iverilog and --vvp")
    args.out.mkdir(parents=True,exist_ok=True)
    binary=(args.out/"controller.vvp").resolve()
    command=[args.iverilog]
    if args.ivl_dir: command += ["-B",str(args.ivl_dir)]
    command += ["-g2012","-s","tb_h_learning_controller","-o",str(binary),
                str(ROOT/"rtl"/"h_learning_controller.sv"),str(ROOT/"rtl"/"tb_h_learning_controller.sv")]
    compile_result=subprocess.run(command,capture_output=True,text=True)
    if compile_result.returncode:
        raise RuntimeError(compile_result.stdout+compile_result.stderr)
    result=subprocess.run([args.vvp,str(binary)],cwd=args.out,capture_output=True,text=True)
    log=compile_result.stdout+compile_result.stderr+result.stdout+result.stderr
    (args.out/"simulator.log").write_text(log)
    version=subprocess.run([args.iverilog,"-V"],capture_output=True,text=True).stdout.splitlines()[0]
    report={"simulator":version,"passed":result.returncode==0 and "PASS:" in result.stdout,
            "scope":"Compact eight-state control core, accelerated synthetic clock and synchronous inputs. No FPGA board execution or neural inference.",
            "returncode":result.returncode,"evidence":"simulator.log and h_learning_controller.vcd"}
    write_json(args.out/"report.json",report)
    print(log); print(report)
    if not report["passed"]: raise SystemExit(1)


if __name__=="__main__": main()

