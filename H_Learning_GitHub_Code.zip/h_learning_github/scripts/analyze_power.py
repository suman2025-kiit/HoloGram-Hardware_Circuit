#!/usr/bin/env python3
"""Integrate externally measured power CSV; no measured values are generated."""
import argparse
import csv
import math
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/"src"))
from h_learning.signals import write_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("input",type=Path);p.add_argument("--meter-description",required=True)
    p.add_argument("--battery-wh",type=float,default=37.0);p.add_argument("--out",type=Path,required=True)
    a=p.parse_args()
    with a.input.open(newline="") as f: rows=list(csv.DictReader(f))
    if len(rows)<2:p.error("At least two measured samples are required")
    samples=[(float(r["time_s"]),float(r["power_w"])) for r in rows]
    if not all(math.isfinite(t) and math.isfinite(v) and v>=0 for t,v in samples):p.error("Invalid measured values")
    if any(b[0]<=a0[0] for a0,b in zip(samples,samples[1:])):p.error("Times must increase strictly")
    if a.battery_wh<=0:p.error("Battery capacity must be positive")
    joules=sum((b[0]-a0[0])*(a0[1]+b[1])/2 for a0,b in zip(samples,samples[1:]))
    seconds=samples[-1][0]-samples[0][0]
    report={"samples":len(samples),"duration_s":seconds,"mean_measured_power_w":joules/seconds,
            "integrated_energy_j":joules,"integrated_energy_wh":joules/3600,
            "nominal_battery_wh":a.battery_wh,"nominal_capacity_fraction_percent":100*joules/3600/a.battery_wh,
            "meter_description":a.meter_description,
            "scope":"External meter samples. Capacity fraction ignores battery ageing and regulator losses; it is not observed state of charge."}
    write_json(a.out,report);print(report)


if __name__=="__main__":main()

