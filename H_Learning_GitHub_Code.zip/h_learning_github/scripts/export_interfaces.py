#!/usr/bin/env python3
"""Export actual signal logs to MATLAB, QSPICE PWL and WaveDrom interfaces.

QSPICE tests comparator/validity gating and an RC signal interface. The CSV
FSM outputs are references, not independently simulated neural networks.
"""

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from h_learning.controller import Controller
from h_learning.downloads import sha256
from h_learning.signals import read_signals,write_csv,write_json


def pwl(path, times, values):
    points=[(0.0,values[0])]
    for i,(t,v) in enumerate(zip(times,values)):
        if i==0:
            if t>0: points.append((t,v))
            continue
        if v!=values[i-1]:
            eps=min(1e-6,(t-times[i-1])/10)
            if t-eps>points[-1][0]: points.append((t-eps,values[i-1]))
            points.append((t,v))
    if times[-1]>points[-1][0]: points.append((times[-1],values[-1]))
    path.write_text("".join(f"{t:.9g} {v:.9g}\n" for t,v in points))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path); parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    rows=list(read_signals(args.input))
    if not rows: parser.error("Empty signal CSV")
    args.out.mkdir(parents=True,exist_ok=True)
    controller=Controller()
    decisions=[controller.step(s) for s in rows]
    times=[s.time_ms/1000 for s in rows]
    signals={
        "depth":[s.depth_rel*3.3 for s in rows],
        "depthvalid":[int(s.depth_valid)*3.3 for s in rows],
        "posevalid":[int(s.pose_valid)*3.3 for s in rows],
        "paired":[int(d.paired_valid)*3.3 for d in decisions],
        "mode":[s.mode*3.3 for s in rows],
        "gesture":[int(s.gesture not in {"NONE","CANCEL"})*3.3 for s in rows],
        "lesson":[int(s.lesson_ready)*3.3 for s in rows],
        "alert_reference":[int(d.alert)*3.3 for d in decisions],
    }
    for name,values in signals.items(): pwl(args.out/(name+".pwl"),times,values)
    rows_matlab=[]
    for s,d in zip(rows,decisions):
        rows_matlab.append({"time_s":s.time_ms/1000,"frame_id":s.frame_id,"start":int(s.start),
                            "depth_valid":int(s.depth_valid),"pose_valid":int(s.pose_valid),"paired_valid":int(d.paired_valid),
                            "mode":s.mode,"gesture_valid":int(bool(d.command)),"abnormal_evidence":int(s.abnormal_evidence),
                            "answer_valid":int(s.gesture=="ANSWER" and bool(s.answer)),"answer_correct":int(s.answer==controller.answer_keys[d.lesson_index]),
                            "cancel":int(s.cancel),"reset":int(s.reset),"depth_rel":s.depth_rel,
                            "common_reference":d.common_code,"education_reference":d.education_code,"alert_reference":int(d.alert)})
    write_csv(args.out/"matlab_signals.csv",rows_matlab)
    netlist=["* H-Learning voltage-interface experiment; source trace: "+args.input.name,
             "* Validity flags, not numeric depth AND pose. External neural inference is not in this circuit."]
    for name in signals: netlist.append(f"V{name} {name} 0 PWL FILE=\"{name}.pwl\"")
    netlist += ["Rdepth depth depth_filtered 10k","Cdepth depth_filtered 0 1u",
                "Bfusion fusion 0 V=3.3*if((V(depthvalid)>1.65)&&(V(posevalid)>1.65)&&(V(paired)>1.65),1,0)",
                "Bmonitor monitor_gate 0 V=3.3*if((V(fusion)>1.65)&&(V(mode)<1.65),1,0)",
                "Bedu education_gate 0 V=3.3*if((V(fusion)>1.65)&&(V(mode)>1.65)&&(V(gesture)>1.65)&&(V(lesson)>1.65),1,0)",
                f".tran 0 {max(times[-1],.001):.9g} 0 0.001", ".end"]
    (args.out/"H_Learning_Interface.cir").write_text("\n".join(netlist)+"\n")
    # WaveDrom has a uniform tick axis. Store timestamps separately rather than
    # implying equal physical spacing for irregular source samples.
    wave=[]
    for name in ("depthvalid","posevalid","paired","mode","gesture","lesson","alert_reference"):
        bits=["1" if v>1.65 else "0" for v in signals[name]]
        wave.append({"name":name,"wave":"".join(bit if i==0 or bit!=bits[i-1] else "." for i,bit in enumerate(bits))})
    write_json(args.out/"timing_wavedrom.json",{"signal":wave,"head":{"text":"Sample-index timing; actual times in matlab_signals.csv"}})
    write_json(args.out/"export_metadata.json",{"input_sha256":sha256(args.input),"source_kinds":sorted({s.source_kind for s in rows}),
               "frames":len(rows),"scope":"Voltage-interface model and compact-controller input replay. WaveDrom only renders timing; QSPICE/Simulink execution must be run in those tools."})
    print(f"Exported {len(rows)} samples to {args.out}")


if __name__=="__main__": main()

