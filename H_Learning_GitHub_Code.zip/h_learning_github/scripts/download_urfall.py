#!/usr/bin/env python3
"""Download official UR Fall features and optional RGB/depth recordings.

External data: CC BY-NC-SA 4.0, Kwolek and Kepski (2014). Not MIT code data.
"""

from __future__ import annotations

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from h_learning.downloads import download, save_manifest

BASE = "https://fenix.ur.edu.pl/mkepski/ds/data/"
PAGE = "https://fenix.ur.edu.pl/mkepski/ds/uf.html"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / "data" / "urfall")
    parser.add_argument("--sync", action="store_true", help="Download real camera-0 timestamps for all 70 sequences")
    parser.add_argument("--clips", nargs="*", default=[], help="e.g. fall-01 adl-01; downloads cam0 RGB/depth ZIPs and synchronization CSVs")
    parser.add_argument("--videos", action="store_true", help="Download official MP4 previews for requested clips")
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    names = ["urfall-cam0-falls.csv", "urfall-cam0-adls.csv"]
    sequences = [f"fall-{i:02d}" for i in range(1, 31)] + [f"adl-{i:02d}" for i in range(1, 41)]
    if args.sync:
        names += [s + "-data.csv" for s in sequences]
    for clip in args.clips:
        if clip not in sequences:
            parser.error(f"Unknown sequence: {clip}")
        names += [clip + "-data.csv", clip + "-cam0-rgb.zip", clip + "-cam0-d.zip"]
        if args.videos:
            names += [clip + "-cam0.mp4"]
    names = list(dict.fromkeys(names))

    def get(name: str) -> dict:
        entry = download(BASE + name, args.out / name)
        print(f"{name}: {entry['bytes']} bytes", flush=True)
        return entry

    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, 8))) as pool:
        entries = list(pool.map(get, names))
    save_manifest(args.out / "download_manifest.json", entries,
                  dataset="UR Fall Detection Dataset", source_page=PAGE,
                  licence="CC-BY-NC-SA-4.0", camera=0,
                  provenance="Recorded human activities, obtained from the official host")


if __name__ == "__main__":
    main()

