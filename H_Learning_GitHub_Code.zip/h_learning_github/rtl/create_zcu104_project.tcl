# Run: vivado -mode batch -source rtl/create_zcu104_project.tcl
# Out-of-context synthesis of the control core; not a board bitstream.
set root [file normalize [file join [file dirname [info script]] ..]]
set out [file join $root build vivado_zcu104]
file mkdir $out
create_project -force h_learning_control $out -part xczu7ev-ffvc1156-2-e
add_files [file join $root rtl h_learning_controller.sv]
set_property top h_learning_controller [current_fileset]
update_compile_order -fileset sources_1
synth_design -mode out_of_context -top h_learning_controller -part xczu7ev-ffvc1156-2-e
create_clock -name controller_clk -period 10.000 [get_ports clk]
report_utilization -file [file join $out utilization.rpt]
report_timing_summary -file [file join $out timing.rpt]
write_checkpoint -force [file join $out h_learning_control.dcp]
puts "Control-core synthesis complete. Reports do not cover neural inference, board I/O or physical power."

