// Compact Table-III control reference. Neural inference and the full learning
// application execute in host software. All ports must be synchronous to clk.
// Use a clock enable (sample_tick), never a combinationally gated FPGA clock.
module h_learning_controller #(
    parameter integer STABLE_SAMPLES = 2,
    parameter integer ALERT_SAMPLES = 8
) (
    input logic clk, reset, sample_tick, mode,
    input logic start, cancel,
    input logic depth_valid, pose_valid, paired_valid,
    input logic gesture_valid, abnormal_evidence,
    input logic answer_valid, answer_correct,
    output logic [2:0] state,
    output logic fusion_valid, monitor_enable, education_enable,
    output logic alert, command_pulse, feedback_correct
);
    localparam logic [2:0] IDLE=3'd0, DEPTH_READY=3'd1, POSE_READY=3'd2,
        FUSION_READY=3'd3, OUTPUT_STABLE=3'd4, ALERT=3'd5,
        STUDENT_INTERACT=3'd6, FEEDBACK=3'd7;
    logic previous_mode;
    logic [15:0] stable_count, alert_count;
    logic feedback_latch;
    logic command_latch;

    always_ff @(posedge clk) begin
        command_latch <= 1'b0;
        if (reset) begin
            state <= IDLE;
            previous_mode <= mode;
            stable_count <= 0;
            alert_count <= 0;
            feedback_latch <= 0;
        end else if (sample_tick) begin
            previous_mode <= mode;
            if (cancel) begin
                state <= IDLE;
                stable_count <= 0;
                alert_count <= 0;
                feedback_latch <= 0;
            end else if (mode != previous_mode) begin
                state <= DEPTH_READY;
                stable_count <= 0;
                alert_count <= 0;
                feedback_latch <= 0;
            end else if (state != IDLE && !(depth_valid && pose_valid && paired_valid)) begin
                state <= DEPTH_READY;
                stable_count <= 0;
                alert_count <= 0;
            end else begin
                case (state)
                    IDLE: if (start) state <= DEPTH_READY;
                    DEPTH_READY: if (depth_valid) state <= POSE_READY;
                    POSE_READY: if (paired_valid && pose_valid) begin
                        state <= FUSION_READY;
                        stable_count <= 0;
                    end
                    FUSION_READY: begin
                        if (stable_count >= STABLE_SAMPLES-1) state <= OUTPUT_STABLE;
                        else stable_count <= stable_count + 1;
                    end
                    OUTPUT_STABLE: begin
                        if (!mode) begin
                            if (abnormal_evidence) begin
                                if (alert_count >= ALERT_SAMPLES-1) state <= ALERT;
                                else alert_count <= alert_count + 1;
                            end else alert_count <= 0;
                        end else if (gesture_valid) begin
                            state <= STUDENT_INTERACT;
                            command_latch <= 1'b1;
                        end
                    end
                    STUDENT_INTERACT: if (answer_valid) begin
                        state <= FEEDBACK;
                        feedback_latch <= answer_correct;
                    end
                    ALERT: state <= ALERT;
                    FEEDBACK: state <= FEEDBACK;
                    default: state <= IDLE;
                endcase
            end
        end
    end

    always_comb begin
        fusion_valid = state >= OUTPUT_STABLE && depth_valid && pose_valid && paired_valid
                       && (mode == previous_mode) && !cancel && !reset;
        monitor_enable = fusion_valid && !mode;
        education_enable = fusion_valid && mode;
        command_pulse = command_latch && education_enable;
        alert = monitor_enable && state == ALERT;
        feedback_correct = education_enable && state == FEEDBACK && feedback_latch;
    end
endmodule
