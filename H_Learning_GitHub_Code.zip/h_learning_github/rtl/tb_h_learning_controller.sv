`timescale 1ns/1ps
module tb_h_learning_controller;
    logic clk=0, reset=1, sample_tick=1, mode=1;
    logic start=0, cancel=0, depth_valid=1, pose_valid=1, paired_valid=1;
    logic gesture_valid=0, abnormal_evidence=0, answer_valid=0, answer_correct=0;
    wire [2:0] state;
    wire fusion_valid, monitor_enable, education_enable, alert, command_pulse, feedback_correct;
    integer checks=0;
    always #5 clk=~clk;
    h_learning_controller #(.STABLE_SAMPLES(2),.ALERT_SAMPLES(3)) dut(.*);

    task tick; begin @(posedge clk); #1; end endtask
    task check(input logic condition, input string message);
        begin
            checks=checks+1;
            if (!condition) $fatal(1,"FAIL: %s, state=%0d",message,state);
        end
    endtask
    task recover;
        begin repeat(4) tick(); check(state==4,"reacquisition reaches stable output"); end
    endtask

    always @(negedge clk) begin
        if (monitor_enable && education_enable) $fatal(1,"Both branches enabled");
        if ((alert || command_pulse) && !(depth_valid && pose_valid && paired_valid))
            $fatal(1,"Output without paired tracking");
        if (alert && mode) $fatal(1,"Alert in learning mode");
    end

    initial begin
        $dumpfile("h_learning_controller.vcd"); $dumpvars(0,tb_h_learning_controller);
        tick(); check(state==0,"reset goes idle");
        reset=0; start=1; tick(); check(state==1,"start");
        start=0; tick(); check(state==2,"depth ready");
        tick(); check(state==3,"pose ready");
        tick(); check(state==3,"first stabilization sample");
        tick(); check(state==4 && education_enable && !monitor_enable,"exclusive learning enable");
        gesture_valid=1; tick(); check(state==6 && command_pulse,"authorized interaction");
        gesture_valid=0; answer_valid=1; answer_correct=1;
        tick(); check(state==7 && feedback_correct && !command_pulse,"positive feedback");
        answer_valid=0; paired_valid=0; #1;
        check(!education_enable && !fusion_valid,"stale frame immediately gates output");
        tick(); check(state==1,"tracking-loss restart");
        paired_valid=1; recover();
        mode=0; #1; check(!education_enable && !monitor_enable,"mode change immediately gates both");
        tick(); check(state==1,"mode switch restart"); recover();
        check(monitor_enable && !education_enable,"exclusive monitoring enable");
        abnormal_evidence=1; tick(); check(!alert,"one sample cannot alert");
        tick(); check(!alert,"two samples cannot alert with threshold three");
        tick(); check(state==5 && alert,"persistent evidence alerts");
        abnormal_evidence=0; tick(); check(alert,"alert held pending reset");
        cancel=1; tick(); check(state==0 && !alert,"cancel has priority");
        cancel=0; start=1; tick(); start=0; recover();
        reset=1; tick(); check(state==0,"reset clears accepted alert");
        $display("PASS: %0d checks; compact control simulation only",checks);
        $finish;
    end
endmodule

