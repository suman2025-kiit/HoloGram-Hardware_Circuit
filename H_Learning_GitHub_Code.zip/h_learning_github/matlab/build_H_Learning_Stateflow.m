function modelPath = build_H_Learning_Stateflow(csvPath, outDir)
% Actual Simulink/Stateflow compact control model builder, not a UI illustration.
% Requires MATLAB, Simulink and Stateflow. This script was not executed in the
% delivery environment; Python and RTL execution evidence is supplied instead.
% Input: scripts/export_interfaces.py output matlab_signals.csv.
% Scope: Table-III compact FSM, not the complete host learning application.

arguments
    csvPath (1,:) char
    outDir (1,:) char = 'runs/matlab'
end
assert(license('test','Simulink') && license('test','Stateflow'), ...
    'MATLAB, Simulink and Stateflow licences are required.');
if ~isfolder(outDir), mkdir(outDir); end
T = readtable(csvPath);
t = double(T.time_s(:)); t = t-t(1);
assert(all(diff(t)>0),'CSV times must increase strictly.');
Ts = 0.001; % A replay grid. Application state updates use frame strobes only.
assert(all(diff(t)>=Ts),'This compact replay requires >=1 ms between samples.');
grid = (0:Ts:ceil(t(end)/Ts)*Ts)';
names = {'start','depth_valid','pose_valid','paired_valid','mode', ...
    'gesture_valid','abnormal_evidence','answer_valid','answer_correct','cancel','reset'};
original = zeros(height(T),11);
for k=1:11, original(:,k)=double(T.(names{k})); end
held = interp1(t,original,grid,'previous','extrap');
ids = interp1(t,double(T.frame_id),grid,'previous','extrap');
strobe = [1; double(diff(ids)~=0)];
modeChange = [0; double(diff(held(:,5))~=0)];
depth = interp1(t,double(T.depth_rel),grid,'previous','extrap');
u = [held,strobe,modeChange,depth];
input_ts = timeseries(u,grid);

model = 'H_Learning_Compact';
assert(~bdIsLoaded(model),'Close the existing H_Learning_Compact model first.');
modelPath = fullfile(outDir,[model '.slx']);
assert(~isfile(modelPath),'Output model exists; choose a new output directory.');
sfnew(model);
set_param(model,'SolverType','Fixed-step','Solver','FixedStepDiscrete', ...
    'FixedStep',num2str(Ts),'StopTime',num2str(grid(end)), ...
    'SignalLogging','on','SignalLoggingName','logsout');
ch = sfroot;
chart = ch.find('-isa','Stateflow.Chart','Path',[model '/Chart']);
assert(numel(chart)==1,'Could not resolve the Stateflow chart.');
chart.ActionLanguage = 'MATLAB'; chart.ChartUpdate = 'DISCRETE';
chart.SampleTime = num2str(Ts);
d=Stateflow.Data(chart); d.Name='u'; d.Scope='Input';
d.DataType='double'; d.Props.Array.Size='[1 14]';
d=Stateflow.Data(chart); d.Name='q'; d.Scope='Output';
d.DataType='double'; d.Props.Array.Size='[1 2]';
for name={'stableCount','alertCount','correct'}
    d=Stateflow.Data(chart); d.Name=name{1}; d.Scope='Local';
    d.DataType='double'; d.Props.InitialValue='0';
end

labels={'Idle','DepthReady','PoseReady','FusionReady', ...
    'OutputStable','Alert','StudentInteract','Feedback'};
states=cell(1,8);
for k=1:8
    s=Stateflow.State(chart);
    s.Position=[40+mod(k-1,4)*230,40+floor((k-1)/4)*210,185,110];
    action=sprintf('%s\nentry: q = [%d, 0];',labels{k},k-1);
    if k==1, action=[action newline 'stableCount=0; alertCount=0; correct=0;']; end
    if k==4
        action=[action newline 'stableCount=0;' newline ...
            'during: if u(12)>0.5, stableCount=stableCount+1; end'];
    elseif k==5
        action=[action newline 'alertCount=0;' newline ...
            'during: if u(12)>0.5' newline ...
            'if u(5)<0.5 && u(7)>0.5, alertCount=alertCount+1; else, alertCount=0; end' newline 'end'];
    elseif k==8
        action=sprintf('%s\nentry: q = [7, correct];',labels{k});
    end
    s.LabelString=action; states{k}=s;
end
transitionCounts=zeros(1,8);
tr=Stateflow.Transition(chart); tr.Destination=states{2};
tr.DestinationOClock=0;
tr.SourceEndpoint=tr.DestinationEndpoint-[0 35];
tr.Midpoint=tr.DestinationEndpoint-[0 18];
% Automatic initial acquisition mirrors an active host session. Explicit START
% is required to leave Idle after compact-chart cancel/reset.

valid='u(2)>0.5 && u(3)>0.5 && u(4)>0.5';
for k=1:8
    connect(states{k},states{1},'[u(12)>0.5 && (u(11)>0.5 || u(10)>0.5)]',1);
    connect(states{k},states{2}, ...
        '[u(12)>0.5 && u(13)>0.5 && u(11)<0.5 && u(10)<0.5]',2);
    if k~=1
        connect(states{k},states{2},['[u(12)>0.5 && ~(' valid ')]'],3);
    end
end
connect(states{1},states{2},'[u(12)>0.5 && u(1)>0.5]',4);
connect(states{2},states{3},['[u(12)>0.5 && ' valid ']'],4);
connect(states{3},states{4},['[u(12)>0.5 && ' valid ']'],4);
connect(states{4},states{5},['[u(12)>0.5 && ' valid ' && stableCount>=1]'],4);
connect(states{5},states{6}, ...
    '[u(12)>0.5 && u(5)<0.5 && u(7)>0.5 && alertCount>=7]',4);
connect(states{5},states{7},'[u(12)>0.5 && u(5)>0.5 && u(6)>0.5]',5);
connect(states{7},states{8},'[u(12)>0.5 && u(8)>0.5]{correct=u(9);}',4);

workspace=get_param(model,'ModelWorkspace');
assignin(workspace,'h_learning_input',input_ts);
add_block('simulink/Sources/From Workspace',[model '/RecordedSignals'], ...
    'VariableName','h_learning_input','Interpolate','off','Position',[35 110 165 155]);
set_param([model '/Chart'],'Position',[230 90 390 170]);
gate=[model '/OutputGate'];
add_block('simulink/User-Defined Functions/MATLAB Function',gate,'Position',[460 95 610 165]);
em=sfroot;
f=em.find('-isa','Stateflow.EMChart','Path',gate);
f.Script=sprintf(['function z = gate(q,u)\n' ...
    'valid = u(2)>0.5 && u(3)>0.5 && u(4)>0.5;\n' ...
    'fused = q(1)>=4 && valid && u(10)<0.5 && u(11)<0.5 && u(13)<0.5;\n' ...
    'mon=fused && u(5)<0.5; edu=fused && u(5)>0.5;\n' ...
    'z=[q(1),double(fused),double(mon),double(edu),double(mon && q(1)==5),q(2)];\nend\n']);
add_block('simulink/Sinks/Scope',[model '/ExecutionScope'],'Position',[690 65 750 115]);
add_block('simulink/Sinks/To Workspace',[model '/LoggedOutput'], ...
    'VariableName','compact_output','SaveFormat','Timeseries','Position',[675 145 800 185]);
add_line(model,'RecordedSignals/1','Chart/1','autorouting','on');
add_line(model,'RecordedSignals/1','OutputGate/2','autorouting','on');
line=add_line(model,'Chart/1','OutputGate/1','autorouting','on');
set_param(line,'Name','StateCodeAndFeedback');
line=add_line(model,'OutputGate/1','ExecutionScope/1','autorouting','on');
set_param(line,'Name','CompactControllerOutput','DataLogging','on');
add_line(model,'OutputGate/1','LoggedOutput/1','autorouting','on');
save_system(model,modelPath);
result=sim(model,'ReturnWorkspaceOutputs','on');
logged=result.get('compact_output');
save(fullfile(outDir,'actual_simulation_output.mat'),'logged','input_ts');
values=squeeze(logged.Data);
if size(values,1)~=numel(logged.Time), values=values.'; end
assert(size(values,2)==6,'Unexpected compact-output dimensions.');
assert(~any(values(:,3)>0.5 & values(:,4)>0.5),'Branch exclusivity failure.');
fig=figure('Color','w');
stairs(logged.Time,values(:,[1 3 4 5]),'LineWidth',2);
xlabel('Replay time (s)','FontWeight','bold'); ylabel('State code / flag','FontWeight','bold');
legend('Compact state','Monitoring enabled','Learning enabled','Alert','Location','best');
title('Executed compact Stateflow control simulation'); grid on;
set(gca,'FontSize',13,'FontWeight','bold');
exportgraphics(fig,fullfile(outDir,'Executed_Stateflow_Control.jpg'),'Resolution',300);
fprintf('Actual model and simulation outputs saved to %s\n',outDir);
% Open ExecutionScope or run Simulink.sdi.view for real application captures.

    function connect(source,destination,label,order)
        edge=Stateflow.Transition(chart); edge.Source=source;
        edge.Destination=destination; edge.SourceOClock=3;
        edge.DestinationOClock=9; edge.LabelString=label;
        sourceIndex=find(cellfun(@(s)isequal(s,source),states),1);
        transitionCounts(sourceIndex)=transitionCounts(sourceIndex)+1;
        edge.ExecutionOrder=min(order,transitionCounts(sourceIndex));
    end
end
