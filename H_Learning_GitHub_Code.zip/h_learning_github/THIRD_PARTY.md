# Upstream components

| Component | Official origin | Terms / attribution |
|---|---|---|
| UR Fall recordings and features | https://fenix.ur.edu.pl/mkepski/ds/uf.html | CC BY-NC-SA 4.0; Kwolek and Kepski (2014); see `data/DATA_LICENSE.md` |
| MiDaS v2.1 small ONNX | https://github.com/isl-org/MiDaS | Upstream repository is MIT; models retain provider terms and model-paper citation requirements; weights downloaded separately |
| MediaPipe Pose Landmarker lite | https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker | Official model bundle and model card govern weights; MediaPipe code is Apache 2.0; weights downloaded separately |
| MediaPipe source | https://github.com/google-ai-edge/mediapipe | Apache 2.0 |
| OpenCV | https://github.com/opencv/opencv | Apache 2.0 for current releases |
| NumPy | https://numpy.org | BSD licence |
| SciPy | https://scipy.org | BSD licence |
| Matplotlib | https://matplotlib.org | Matplotlib licence |
| Icarus Verilog | https://github.com/steveicarus/iverilog | GPL; external execution tool, not bundled |
| WaveDrom | https://wavedrom.com | External timing renderer; its source licence governs that tool |
| MATLAB, Simulink, Stateflow | https://www.mathworks.com | External licensed tools, not bundled |
| Vivado / ZCU104 | https://www.amd.com/en/products/adaptive-socs-and-fpgas/evaluation-boards/zcu104.html | External platform/tools; no hardware supplied |
| QSPICE | https://www.qorvo.com/design-hub/design-tools/interactive/qspice | External simulator under its provider's terms |

No upstream model was trained, pruned or quantized by this repository. Download
records and SHA256 values identify the upstream bytes used for actual runs.
The original manuscript references a different hardware/software setting;
this prototype's evidence applies only to the recorded configurations.

